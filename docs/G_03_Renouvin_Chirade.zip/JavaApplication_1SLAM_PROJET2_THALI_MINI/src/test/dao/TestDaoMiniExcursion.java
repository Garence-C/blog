package test.dao;

import modele.dao.ConnexionBDD;
import modele.dao.DaoMiniExcursion;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.metier.MiniExcursion;

/**
 *
 * @author nb
 */
public class TestDaoMiniExcursion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String code;
        
        // Test 1 getAll
        System.out.println("\n Test 1 : TestDaoMiniExcursion.getAll");
        try {
            code = "E02";
            MiniExcursion miniex = DaoMiniExcursion.getOneById(code);
            if (miniex != null) {
                System.out.println("Etape d'id (\"" + code + "\") trouvée : \n" + miniex.toString());
            }else{
                System.out.println("Etape d'id (\"" + code +"\") non trouvée : \n");
            }
        } catch (SQLException  ex) {
            System.out.println("TestDaoEtape - échec getOneById : " + ex.getMessage());
            Logger.getLogger(TestDaoMiniExcursion.class.getName()).log(Level.SEVERE, "Echec test 2", ex);
        }
        
        // Test 2 getOneById
        System.out.println("\n Test 2 : TestDaoMiniExcursion.getOneById");
        try {
            ArrayList<MiniExcursion> lesExcursions = DaoMiniExcursion.getAll();
            for (MiniExcursion exc : lesExcursions) {
                System.out.println(exc.toStringEtat());
            }
            System.out.println(lesExcursions.size()+" excursions trouvées");
        } catch (SQLException ex) {
            Logger.getLogger(TestDaoMiniExcursion.class.getName()).log(Level.SEVERE, "TestDaoMiniExcursion - échec getAll : ", ex);
        }
        
        // Fermeture de la connexion
        try {
            ConnexionBDD.getConnexion().close();
            System.out.println("\nConnexion à la BDD fermée");
        } catch (SQLException ex) {
            Logger.getLogger(TestDaoMiniExcursion.class.getName()).log(Level.SEVERE, "TestDaoMiniExcursion - échec de la fermeture de la connexion : ", ex);
        }
    }
    
    
}
