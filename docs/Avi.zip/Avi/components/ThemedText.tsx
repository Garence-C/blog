//
import React from "react";
import { StyleSheet, Text, TextProps } from "react-native";

// Propriétés étendues pour permettre différents styles et couleurs
type Props = TextProps & {
  variant?: "h1" | "h2" | "regular" | "form"; // Choix du style de texte
  color?: string; // Couleur personnalisée
};

export default function ThemedText({
  variant = "regular", // Style par défaut
  color,
  style,
  ...rest
}: Props) {
  // Sélection du style selon le variant

  const variantStyle = styles[variant] || styles.h2;

  // VariantStyle : Application du style,
  // color && { color } : override de la couleur par défaut si la propriété color est utilisée,
  // style : passe des styles personnalisés en plus
  // {...rest} : les autres propriétés sont insérées dans le style en plus
  return <Text style={[variantStyle, color && { color }, style]} {...rest} />;
}

// Définition des styles pour chaque variant
const styles = StyleSheet.create({
  h1: {
    fontFamily: "RobotoCondensed-Bold",
    fontWeight: "bold",
    fontSize: 35,
    lineHeight: 41,
  },
  h2: {
  fontFamily: "RobotoCondensed-Medium",
    fontSize: 20,
    lineHeight: 23.4,
  },
  regular: {
    fontFamily: "RobotoCondensed-Regular",
    fontSize: 15,
    lineHeight: 17.6,
  },
  form: {
    fontFamily: "RobotoCondensed-Regular",
    lineHeight: 23.4,
    marginBottom: 5,
    marginTop: 10,
    fontWeight: 'bold',
    fontSize: 16 
  }
});
