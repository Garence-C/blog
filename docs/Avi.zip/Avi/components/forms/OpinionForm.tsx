import Rating from "@/components/primitive/Rating";
import ThemedText from "@/components/ThemedText";
import { Controller, UseFormReturn } from "react-hook-form";
import { StyleSheet, TextStyle, View, ViewStyle } from "react-native";
import { FormInput } from "../primitive/FormInput";

export type OpinionFormValue = {
  price: string;
  rating: number | null;
  commentary: string;
};

type Props = {
  form: UseFormReturn<OpinionFormValue>;
  variant: "edit" | "create";
};

export function OpinionForm({ form, variant }: Props) {
  const {
    control,
    formState: { errors },
  } = form;

  return (
    <View style={styles.endContent}>
      {/* PRICE */}
      <ThemedText variant="form" style={styles.label}>
        Quel a été {variant === "edit"
          ? "le prix pour une nuit ?"
          : "le montant de l'addition ?"}
      </ThemedText>

      <Controller
        control={control}
        name="price"
        rules={{
          required: "Le prix est obligatoire",
          pattern: {
            value: /^\d+([.,]\d{0,2})?$/,
            message: "Format invalide (ex: 20 ou 20.00)",
          },
        }}
        render={({ field, fieldState }) => (
          <FormInput
            value={field.value}
            onChangeText={field.onChange}
            onBlur={field.onBlur}
            keyboardType="decimal-pad"
            placeholder="20.00€"
            error={fieldState.error?.message}
            newInputStyle={styles.inputPrice}
          />
        )}
      />

      {/* RATING */}
      <ThemedText variant="form" style={styles.label}>
        Quelle note donneriez-vous à votre expérience ?
      </ThemedText>

      <Controller
        control={control}
        name="rating"
        rules={{ required: "La note est obligatoire" }}
        render={({ field }) => (
          <Rating value={field.value} onChange={field.onChange} />
        )}
      />

      {errors.rating && (
        <ThemedText style={styles.error}>
          {errors.rating.message}
        </ThemedText>
      )}

      {/* COMMENTARY */}
      <ThemedText variant="form" style={styles.label}>
        Écrivez quelques lignes pour raconter votre expérience ?
      </ThemedText>

      <Controller
        control={control}
        name="commentary"
        rules={{ required: "Le commentaire est obligatoire" }}
        render={({ field, fieldState }) => (
          <FormInput
            value={field.value}
            onChangeText={field.onChange}
            onBlur={field.onBlur}
            placeholder="Votre expérience"
            multiline
            numberOfLines={6}
            textAlignVertical="top"
            maxLength={2000}
            error={fieldState.error?.message}
            newInputStyle={styles.exp}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create<{
  endContent: ViewStyle;
  contentConfirm: ViewStyle;
  label: TextStyle;
  inputPrice: TextStyle;
  exp: TextStyle;
  error: TextStyle;
}>({
  endContent: {
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 10,
    gap: 10,
    paddingBottom: 25
  },
  label: {
    marginBottom: 2,
    marginTop: 10,
    fontWeight: "bold"

  },
  contentConfirm: {
    justifyContent:
      "center",
    marginInline: "auto"

  },
  inputPrice: {
    marginBottom: 12,
    width: 65,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#B9375E",
    fontSize: 13,
    paddingHorizontal: 10
  },
  exp: {
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#B9375E",
    fontSize: 13,
    paddingHorizontal: 10,
    height: 100
  },
  inputError: {
    borderColor: "red",
  },
  error: {
    color: "red",
    marginTop: 4,
    fontSize: 12,
  },
});
