import { MaterialIcons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

type ButtonFormProps = {
  options?: string[];
  defaultValue?: string;
  onSelect?: (value: string) => void;
};


export default function ButtonForm({
  options = ['Oui', 'Non'],
  defaultValue = 'Oui',
  onSelect,
}: ButtonFormProps) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(defaultValue);

  const toggleDropdown = () => setOpen(!open);

  const handleSelect = (value) => {
    setSelected(value);
    setOpen(false);
    if (onSelect) onSelect(value);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={toggleDropdown}>
        <Text style={styles.buttonText}>{selected}</Text>
        <MaterialIcons
          name={open ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
          size={20}
          color="#B9375E"
        />
      </TouchableOpacity>

      {open && (
        <View style={styles.dropdown}>
          {options.map((option) => (
            <TouchableOpacity 
              key={option} 
              onPress={() => handleSelect(option)} 
              style={styles.option}
            >
              <Text style={styles.optionText}>{option}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'flex-start',
    marginTop: 10
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#B9375E',
    paddingHorizontal: 10,
    height: 35,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
  },
  buttonText: {
    color: '#B9375E',
    fontSize: 14,
    marginRight: 5,
  },
  dropdown: {
    marginTop: 5,
    borderWidth: 1.5,
    borderColor: '#B9375E',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    width: 70,
  },
  option: {
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  optionText: {
    color: '#B9375E',
    fontSize: 14
  },
});
