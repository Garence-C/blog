/** Non utilisé pour le moment */

import * as Location from "expo-location";
import { MapPin } from "lucide-react-native";
import React, { useState } from "react";
import { Pressable, StyleSheet, View } from "react-native";
import ThemedText from "../ThemedText";
import { Input } from "../primitive/Input";

type ActionItemProps = {
    label: string;
    placeholder: string;
    initialName: string;
    initialCity: string;
    initialPostCode: number;
    initialAddress: string;
    initialTel: number;
    initialEmail: string;
    onPress: () => void;
    withBorder?: boolean;
};

export default function AddForm({
    label,
    placeholder,
    initialName,
    initialCity,
    initialPostCode,
    initialAddress,
    initialTel,
    initialEmail,
    onPress,
    withBorder = false,
}: ActionItemProps) {

    const [name, setName] = useState({initialName})
    const [city, setCity] = useState({initialCity})
    const [postCode, setPostCode] = useState({initialPostCode})
    const [longitude, setLongitude] = useState<number>()
    const [latitude, setLatitude] = useState<number>()
    const [address, setAddress] = useState({initialAddress})
    const [tel, setTel] = useState({initialTel})
    const [email, setEmail] = useState({initialEmail})


    const getUserLocation = async () => {
        try {
            // Demande de permission
            const { status } = await Location.requestForegroundPermissionsAsync()
            if (status !== 'granted') {
                console.log('Permission refusée')
                return
            }

            // Récupération de la position
            const location = await Location.getCurrentPositionAsync({
                accuracy: Location.Accuracy.High,
            })

            console.log('Latitude:', location.coords.latitude)
            console.log('Longitude:', location.coords.longitude)

            setLatitude(location.coords.latitude)
            setLongitude(location.coords.longitude)

            // Reverse Geocoding pour récupérer la ville et code postal
            const addressData = await Location.reverseGeocodeAsync({
                latitude: location.coords.latitude,
                longitude: location.coords.longitude,
            });

            if (addressData.length > 0) {
                const data = addressData[0];
                setCity(data.city || '');
                setPostCode(data.postalCode || '');

                const fullAddress = [data.name, data.street]
                    .filter(Boolean)
                    .join(', ');
                setAddress(fullAddress);
            }

        } catch (error) {
            console.log('Erreur GPS:', error)
        }
    }

    return (
        <>
            <ThemedText variant={'form'} color="black" style={styles.label}>
                {label}
            </ThemedText>
            <Input placeholder={placeholder} placeholderTextColor={"#B9375E"} value={name} onChangeText={setName} style={styles.input} />


            <ThemedText variant={'form'} color="black" style={styles.label} >
                Ville
            </ThemedText>
            <Input placeholder="Ville" placeholderTextColor={"#B9375E"} value={city} onChangeText={setCity} style={styles.input} />
            <ThemedText variant={'form'} color="black" style={styles.label} >
                Code postal
            </ThemedText>
            <Input placeholder="Code postal" placeholderTextColor={"#B9375E"} value={postCode} onChangeText={setPostCode} style={styles.input} />


            <ThemedText variant={'form'} color="black" style={styles.label} >
                Adresse
            </ThemedText>
            <View style={{ flexDirection: 'row', gap: 4 }}>
                <Input placeholder="Adresse" placeholderTextColor={"#B9375E"} value={address} onChangeText={setAddress} style={styles.inputWith2} />
                <Pressable
                    style={{
                        backgroundColor: '#FFE0E9',
                        borderRadius: 8,
                        alignItems: 'center',
                        padding: 12,
                        height: 44,
                        paddingTop: 12,
                        width: '12%'
                    }}
                    onPressIn={getUserLocation}
                >
                    <MapPin color={'#B9375E'} size={16} />
                </Pressable>

            </View>


            <ThemedText variant={'form'} color="black" style={styles.label} >
                N° de téléphone
            </ThemedText>
            <Input placeholder="02.02.02.02.02" placeholderTextColor={"#B9375E"} value={tel} onChangeText={setTel} style={styles.input} />
            <ThemedText variant={'form'} color="black" style={styles.label} >
                E-mail
            </ThemedText>
            <Input placeholder="contact@hotel.fr" placeholderTextColor={"#B9375E"} value={email} onChangeText={setEmail} style={styles.input} />
        </>
    )
}



const styles = StyleSheet.create({
    label: {
        marginBottom: 2,
        marginTop: 10,
        fontWeight: 'bold',
    },
    input: {
        marginBottom: 12,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: '#B9375E',
        fontSize: 13,
        paddingHorizontal: 10,
    },
    inputWith2: {
        marginBottom: 12,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: '#B9375E',
        fontSize: 13,
        paddingHorizontal: 10,
        width: '88%',
    },
});
