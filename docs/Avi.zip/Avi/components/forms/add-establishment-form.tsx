import { StyleSheet, TextStyle, View, ViewStyle } from "react-native";
import { Input } from "../primitive/Input";
import ThemedText from "../ThemedText";


export type EstablishmentFormValue = {
    name: string,
    city: string,
    postCode: string,
    longitude: string,
    latitude: string,
    address: string,
    tel: string,
    email: string,
    typeId: number | null
}

type EstablishmentFormProps = {
    value: EstablishmentFormValue;
    isLoading?: boolean;
    error?: string | null;
    onChange: (next: Partial<EstablishmentFormValue>) => void;
}


export function AddEstablishmentForm({
    value, isLoading, error, onChange
}: EstablishmentFormProps) {
    return (
        <View style={styles.content}>
            <ThemedText variant="form" color="black" style={styles.label}>
                Nom de l'étalissement
            </ThemedText>
            <Input
                placeholder="Nom de l'établissement"
                placeholderTextColor="#B9375E"
                value={value.name}
                onChangeText={(name) => onChange({ name })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                Ville
            </ThemedText>
            <Input
                placeholder="Ville"
                placeholderTextColor="#B9375E"
                value={value.city}
                onChangeText={(city) => onChange({ city })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                Code postal
            </ThemedText>
            <Input
                placeholder="Code postal"
                placeholderTextColor="#B9375E"
                value={value.postCode}
                onChangeText={(postCode) => onChange({ postCode })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                Adresse
            </ThemedText>
            <Input
                placeholder="Adresse"
                placeholderTextColor="#B9375E"
                value={value.address}
                onChangeText={(address) => onChange({ address })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                N° de téléphone
            </ThemedText>
            <Input
                placeholder="02.02.02.02.02"
                placeholderTextColor="#B9375E"
                value={value.tel}
                onChangeText={(tel) => onChange({ tel })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                E-mail
            </ThemedText>
            <Input
                placeholder="contact@hotel.fr"
                placeholderTextColor="#B9375E"
                value={value.email}
                onChangeText={(email) => onChange({ email })}
                style={styles.input}
            />

            <ThemedText variant="form" color="black" style={styles.label}>
                Quel type d'établissement s'agit-il ?
            </ThemedText>
            {error && (
                <ThemedText style={styles.error}>
                    {error}
                </ThemedText>
            )}

        </View>
    )
}

const styles = StyleSheet.create<{
    // Enlève les erreurs de type en définissant explicitement les types
    container: ViewStyle,
    label: TextStyle,
    content: ViewStyle,
    contentButton: ViewStyle,
    contentButtonForm: ViewStyle,
    contentConfirm: ViewStyle,
    input: TextStyle,
    inputPrice: TextStyle,
    exp: TextStyle,
    error: TextStyle
}>({
    container: {
        flex: 1,
        justifyContent: "flex-start",
        backgroundColor: "#FFFFFF",
        marginBottom: 90,
        paddingTop: 20
    },
    label: {
        marginBottom: 2,
        marginTop: 10,
        fontWeight: 'bold',
    },
    content: {
        marginTop: 15,
        marginRight: 25,
        marginLeft: 25,
        marginBottom: 14,
        gap: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#E4E4E4',
        paddingBottom: 25
    },
    contentButton: {
        marginTop: 15,
        marginBottom: 4,
        flexDirection: 'row'
    },
    contentButtonForm: {
        marginTop: 14,
        marginBottom: 12,
        marginLeft: 25,
        gap: 10
    },
    contentConfirm: {
        justifyContent: 'center',
        marginTop: 24,
        marginInline: 'auto',
    },
    input: {
        marginBottom: 12,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: '#B9375E',
        fontSize: 13,
        paddingHorizontal: 10
    },
    inputPrice: {
        marginBottom: 12,
        width: 65,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: '#B9375E',
        fontSize: 13,
        paddingHorizontal: 10
    },
    exp: {
        marginBottom: 12,
        borderRadius: 10,
        borderWidth: 1.5,
        borderColor: '#B9375E',
        fontSize: 13,
        paddingHorizontal: 10,
        height: 100,
    },
    error: {
        color: "#B9375E",
        fontWeight: "600",
        marginTop: 6,
    },
})