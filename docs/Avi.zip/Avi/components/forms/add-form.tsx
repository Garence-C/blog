/** Non utilisé pour le moment */

import { BedDouble, Utensils } from "lucide-react-native";
import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import ThemedText from "../ThemedText";
import CustomButton from "../primitive/CustomButton";
import { Input } from "../primitive/Input";

export default function AddForm1() {
  const [name, setName] = useState('')
  const [adress, setAdress] = useState('')
  const [tel, setTel] = useState('')
  const [mail, setMail] = useState('')

  return (
    <View style={styles.content}>
      <ThemedText variant={'form'} color="black" style={styles.label}>
        Nom de l'étalissement
      </ThemedText>
      <Input placeholder="Nom de l'établissement" placeholderTextColor={"#B9375E"} value={name} onChangeText={setName} style={styles.input} />
      <ThemedText variant={'form'} color="black" style={styles.label} >
        Adresse
      </ThemedText>
      <Input placeholder="Adresse" placeholderTextColor={"#B9375E"} value={adress} onChangeText={setAdress} style={styles.input} />
      <ThemedText variant={'form'} color="black" style={styles.label} >
        N° de téléphone
      </ThemedText>
      <Input placeholder="02.02.02.02.02" placeholderTextColor={"#B9375E"} value={tel} onChangeText={setTel} style={styles.input} />
      <ThemedText variant={'form'} color="black" style={styles.label} >
        E-mail
      </ThemedText>
      <Input placeholder="contact@hotel.fr" placeholderTextColor={"#B9375E"} value={mail} onChangeText={setMail} style={styles.input} />
    </View>
  );
}

export function AddForm2() {
  const [typeEtablissement, setTypeEtablissement] = useState('N')
  
  return (
    <View style={styles.content}>
      <ThemedText variant={'form'} color="black" style={styles.label} >
        Quel type d'établissement s'agit-il ?
      </ThemedText>
      <View style={styles.contentButton}>
        <CustomButton 
          onPress={() => {	
            setTypeEtablissement('H')
          }}
          type={typeEtablissement === 'H' ? "primary" : "secondary"}
          size="form"
          sizeText="form"
          title={"Hôtel"}
          icon={<BedDouble size={16} color="#B9375E"/>}
        />
        <CustomButton 
          onPress={() => {
            setTypeEtablissement('R')
          }}
          type={typeEtablissement === 'R' ? "primary" : "secondary"}
          title={"Restaurant"}
          size="form"
          sizeText="form"
          icon={<Utensils size={16} color="#B9375E"/>}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  content: {
    marginTop: 15,
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#E4E4E4',
    paddingBottom: 25
  },
  contentButton: {
    marginTop: 15,
    marginBottom: 4,
    flexDirection: 'row'
  },
  input: {
    borderWidth: 1,
    borderColor: '#E4E4E4',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8
  },
  label: {
    marginTop: 10
  }
});
