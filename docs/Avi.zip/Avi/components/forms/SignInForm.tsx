import { Input } from "@/components/primitive/Input";
import { PasswordInput } from "@/components/primitive/PasswordInput";
import { Colors } from "@/constants/Colors";
import { UserLoginInput } from "@/constants/api/schemas/user.schema";
import { useColorScheme } from "@/hooks/useColorScheme";
import { ArrowRight } from "lucide-react-native";
import React from "react";
import { Controller, UseFormReturn } from "react-hook-form";
import { KeyboardAvoidingView, StyleSheet, View } from "react-native";
import ThemedText from "../ThemedText";
import CustomButton from "../primitive/CustomButton";
import { CustomCheckbox } from "../primitive/CustomCheckbox";

type Props = {
  form: UseFormReturn<UserLoginInput>;
  submitLabel: string;
  isLoading?: boolean;
  onSubmit: () => void
};

export default function SignInForm({
  form,
  submitLabel,
  isLoading,
  onSubmit,
}: Props) {
  const colorScheme = useColorScheme();

  const { control, formState: { errors } } = form;

  return (
    <KeyboardAvoidingView style={styles.container}>
      <View style={styles.form}>
        <View style={styles.textContainer}>
          <ThemedText variant={'h1'} style={[{ color: Colors[colorScheme ?? "light"].pinkDark }]}>
            Connexion
          </ThemedText>
          <ThemedText variant={'h2'}>Saisissez vos identifiants</ThemedText>
        </View>
        <View style={styles.inputContainer}>
          {/* Champ Email */}
          <Controller
            control={control}
            name="email"
            render={({ field }) => (
              <View style={styles.inputContainer}>
                <Input
                  placeholder="E-mail"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                />
                {errors.email && (<ThemedText style={{ color: "red" }}>{errors.email.message}</ThemedText>)}
              </View>
            )}
          />

          {/* Champ Mot de passe */}
          <Controller
            control={control}
            name="password"
            render={({ field }) => (
              <>
                <PasswordInput
                  placeholder="Mot de passe"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                />
                {errors.password && (
                  <ThemedText style={{ color: "red" }}>
                    {errors.password.message}
                  </ThemedText>
                )}
              </>
            )}
          />
        </View>

        {/* Case à cocher "Se souvenir" */}
        <View style={styles.checkboxContainer}>
          <Controller
            control={control}
            name="rememberMe"
            render={({ field }) => (
              <CustomCheckbox
                checked={!!field.value}
                onCheckedChange={(value: boolean) =>
                  field.onChange(value)
                }
              />
            )}
          />
          <ThemedText>Se souvenir de mes identifiants</ThemedText>
        </View>
      </View>

      <View style={styles.connexion}>
        {/* Bouton de connexion */}
        <CustomButton
          onPress={onSubmit}
          type="connexion"
          title={submitLabel}
          sizeText="connexion"
          icon={<ArrowRight size={22} color="#FFFFFF" />}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    justifyContent: "space-between"
  },
  inputContainer: {
    width: '100%',
    rowGap: 15, //espace entre les deux inputs
    marginBottom: 2
  },
  textContainer: {
    rowGap: 10,
    marginBottom: 6
  },
  form: {
    gap: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold"
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    gap: 10
  },
  connexion: {
    gap: 10
  }
});
