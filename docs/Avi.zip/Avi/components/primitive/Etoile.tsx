import { useState } from "react";
import { StyleSheet, View } from "react-native";

const Etoile = ({ type, size = 6.5 }: { type: boolean; size?: number }) => {
    const [isPrimary, setIsPrimary]  = useState(true);
  return (
    <View 
        style={[
            styles.button, 
            { paddingVertical: size, paddingHorizontal: size },
            type ? styles.primary : styles.secondary,
        ]} 
    />
    
  );
};

const styles = StyleSheet.create({
  primary: {
    backgroundColor: '#E05780',
    borderWidth: 1.25,
    borderColor: '#E05780'
  },
  secondary: {
    backgroundColor: '#FFFFFF',
    borderColor: '#E05780',
    borderWidth: 1.25
  },
  button: {
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center'
  }
});

export default Etoile;
