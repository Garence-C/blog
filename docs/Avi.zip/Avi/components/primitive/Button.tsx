import { BorderRadius } from "@/constants/BorderRadius";
import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import { AntDesign } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, TouchableOpacityProps } from "react-native";
import Animated, { Easing, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from "react-native-reanimated";

interface ButtonProps extends TouchableOpacityProps  {
  variant?: 'default' | 'secondary' | 'error' | 'outline';
  size?: 'default' | 'small' | 'large' | 'icon';
  title?: string;
  iconRight?: (props: { size: string, color: string }) => React.ReactNode;
  isSpaced?: boolean;
  isLoading?: boolean;
}

export const Button = React.forwardRef<React.ElementRef<typeof TouchableOpacity>, ButtonProps>(({
  variant = 'default',
  size = 'default',
  title,
  iconRight,
  isSpaced,
  isLoading,
  ...props
}, ref) => {
  const colorScheme = useColorScheme();
  const translateY = useSharedValue(0);
  const translateYLoader = useSharedValue(100);
  const rotation = useSharedValue(0);

  React.useEffect(() => {
    translateY.value = isLoading ? -40 : 0;
    translateYLoader.value = isLoading ? 0 : 40;
  }, [isLoading]);

  React.useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, {
        duration: 1000,
        easing: Easing.linear,
      }),
      -1,
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: withTiming(translateY.value, {
            duration: 300,
          }),
        },
      ],
    };
  });

  const animatedStyleLoader = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: withTiming(translateYLoader.value, {
            duration: 300,
          }),
        },
      ],
    };
  });

  const spinnerStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${rotation.value}deg` }],
    };
  });

  const variantStyles = {
    default: {
      container: {
        backgroundColor: Colors[colorScheme ?? 'light'].pinkDark,
      },
      text: {
        color: Colors[colorScheme ?? 'light'].tint,
      }
    },
    secondary: {
      container: {
        backgroundColor: Colors[colorScheme ?? 'light'].secondary,
      },
      text: {
        color: Colors[colorScheme ?? 'light'].secondaryForeground,
      }
    },
    error: {
      container: {
        backgroundColor: Colors[colorScheme ?? 'light'].error,
      },
      text: {
        color: Colors[colorScheme ?? 'light'].errorForeground,
      }
    },
    outline: {
      container: {
        backgroundColor: Colors[colorScheme ?? 'light'].background,
        borderWidth: 1,
        borderColor: Colors[colorScheme ?? 'light'].input,
      },
      text: {
        color: Colors[colorScheme ?? 'light'].accentForeground,
      }
    },
  };

  const sizeStyles = {
    
    default: {
      container: {
        height: 40,
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: BorderRadius.medium,
      },
    },
    small: {
      container: {
        height: 30,
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: BorderRadius.medium,
      },
    },
    large: {
      container: {
        height: 50,
        paddingVertical: 15,
        paddingHorizontal: 25,
        borderRadius: BorderRadius.medium,
      },
    },
    icon: {
      container: {
        height: 60,
        width: 60,
        borderRadius: 50,
      },
    },
  };

  return (
    <TouchableOpacity
      ref={ref}
      {...props}
      style={[
        styles.button,
        { overflow: 'hidden', opacity: (isLoading || props.disabled) ? 0.6 : 1 },
        variantStyles[variant].container,
        sizeStyles[size].container,
      ]}
      activeOpacity={0.8}
      disabled={isLoading || props.disabled}
    >
      <Animated.View
        style={[
          { justifyContent: isSpaced ? 'space-between' : 'center' },
          styles.buttonChildren,
          animatedStyle
        ]}
      >
        {title && (
          <Text
            style={[
              styles.text,
              variantStyles[variant].text,
            ]}
          >{title}</Text>
        )}
        {iconRight && iconRight({size: '24', ...variantStyles[variant].text})}
      </Animated.View>
      <Animated.View
        style={[
          { justifyContent: 'center' },
          styles.buttonChildren, animatedStyleLoader
        ]}
      >
        <Animated.View style={[spinnerStyle]}>
          <AntDesign name={'loading1'} color={Colors[colorScheme ?? 'light'].primaryForeground} size={20} />
        </Animated.View>
      </Animated.View>
    </TouchableOpacity>
  );
})

const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignItems: 'center',

  },
  buttonChildren: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  text: {
    fontFamily: "Roboto-Condensed",
    fontWeight: "700",
    fontSize: 16,
},
});
