import { Check } from "lucide-react-native";
import { View } from "react-native";
import CustomButton from "./CustomButton";


type SubmitButtonProps = {
  submitLabel: string;
  isLoading?: boolean;
  onPress: () => void;
  isAbsolute?: boolean;
};

export default function SubmitButton({
  submitLabel,
  isLoading,
  onPress,
  isAbsolute = false
}: SubmitButtonProps) {
  return (
    <View
      style={[
        isAbsolute
          ? {
              position: "absolute",
              left: 0,
              right: 0,
              bottom: 130,
              alignItems: "center",
            }
          : { marginHorizontal: "auto" },
      ]}
    >
      <CustomButton
        title={submitLabel}
        type="primary"
        size="small"
        sizeText="avis"
        onPress={onPress}
        disabled={isLoading}
        icon={<Check size={16} color="#B9375E" />}
      />
    </View>
  );
}
