import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import { applyFilters } from "@/hooks/utils/applyFilters";
import { useFilteredEstablishmentsByType } from "@/hooks/utils/useFilteredEstablishmentsByType";
import { BedDouble, Utensils } from "lucide-react-native";
import { useState } from "react";
import { StyleSheet, View } from "react-native";
import CustomButton from "./CustomButton";
import EstablishmentListByType from "./EstablishmentListByType";
import FilterScroll from "./FilterScroll";
import { SearchBar } from "./SearchBar";

type SearchHotelProps = {
    establishments: EstablishmentsResponse["establishments"];
    isResultResearch?: boolean
};
export default function SearchHotel({ establishments, isResultResearch = false }: SearchHotelProps) {
    const [isHotel, setIsHotel] = useState<boolean>(true); // true = hôtels, false = restaurants
    const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

    // Affiche uniquement les établissements d'un type

    const filteredEstablishments = useFilteredEstablishmentsByType({
        allEstablishments: {
            countEstablishments: establishments.length,
            establishments,
        },
        isHotel,
    });

    const finalEstablishments = applyFilters(
        filteredEstablishments ?? [],
        selectedFilters
    );

    const filtersHotelConfig = [
        { id: "bestRated", label: "Le mieux noté" },
        { id: "breakfast", label: "Petit déjeuner inclus" },
        { id: "stageEvening", label: "Soirée étape" },
        { id: "mostRecent", label: "Le plus récent" },
        { id: "price", label: "Tarif" },
    ];

    const filtersRestaurantConfig = [
        { id: "bestRated", label: "Le mieux noté" },
        { id: "evening", label: "Ouvert le midi" },
        { id: "midday", label: "Ouvert le soir" },
        { id: "mostRecent", label: "Le plus récent" },
        { id: "price", label: "Tarif" },
    ];

    function toggleFilter(id: string) {
        setSelectedFilters((prev) =>
            prev.includes(id)
                ? prev.filter((f) => f !== id)
                : [...prev, id]
        );
    }

    const HotelFilters = filtersHotelConfig.map((filter) => ({
        id: filter.id,
        label: filter.label,
        selected: selectedFilters.includes(filter.id),
        onToggle: () => toggleFilter(filter.id)
    }));

    const RestaurantFilters = filtersRestaurantConfig.map((filter) => ({
        id: filter.id,
        label: filter.label,
        selected: selectedFilters.includes(filter.id),
        onToggle: () => toggleFilter(filter.id)
    }));



    /**
       * Boutons permettant de choisir le type d'établissements affichés dans la liste.
       * 
       * @returns la liste des établissments selon le type (bouton) sélectionné.
       */
    function ButtonHeader() {
        return (
            <View style={styles.toggleContainer}>
                <View style={{ flexGrow: 1 }}>

                    <CustomButton
                        onPress={() => setIsHotel(true)} // Met à jour l'état pour afficher les hôtels
                        type={isHotel ? "primary" : "secondary"}
                        title={"Hôtel"}
                        icon={<BedDouble size={22} color="#B9375E" />}
                    />
                </View>
                <View style={{ flexGrow: 1 }}>

                    <CustomButton
                        onPress={() => setIsHotel(false)} // Met à jour l'état pour afficher les restaurants
                        type={!isHotel ? "primary" : "secondary"}
                        title={"Restaurant"}
                        icon={<Utensils size={22} color="#B9375E" />}
                    />
                </View>
            </View>
        )
    }

    // TODO : faire un composant indépendant

    return (
        <>
            <ButtonHeader />

            {/* Barre de recherche */}
            {!isResultResearch && (<SearchBar title="Ville, hôtel ou adresse" type="button" />)}

            {/* TODO : Filtres (statique pour l'instant) */}
            <View 
                style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                gap: 4,
                paddingHorizontal: 4,
                paddingVertical: 4,
                paddingBottom: 8,
            }}
            >
                <FilterScroll
                    filters={isHotel ? HotelFilters : RestaurantFilters}
                    style={styles.filters}
                    variant={"searchHotelScreen"}
                />
            </View>
            
            {console.log("Selected filters:", selectedFilters)}
            {console.log("Filtered establishments:", finalEstablishments.map(e => ({
                name: e.name,
                typeId: e.typeId,
                breakfast: e.breakfast,
                stageEvening: e.stageEvening
            })))}
            {console.log("etablissement sélectionné:", finalEstablishments)}


            {/* Liste des résultats */}
            <EstablishmentListByType establishmentList={finalEstablishments} />

        </>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        paddingHorizontal: 16,
    },
    content: {
        marginTop: 15,
        marginRight: 25,
        marginLeft: 25,
        marginBottom: 14,
        gap: 10,
        borderBottomWidth: 1,
        borderBottomColor: "#E4E4E4",
        paddingBottom: 25,
    },
    toggleContainer: {
        flexDirection: 'row',
        gap: 3,               // spacing moderne et propre
        alignItems: 'center',
        marginTop: 20,
        width: '100%'
    },
    filters: {
        marginVertical: 16,
    },
});
