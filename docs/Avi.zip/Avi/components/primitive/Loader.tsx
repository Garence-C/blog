import React from 'react';
import { ActivityIndicator, View } from 'react-native';

export function Loader() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color="#B9375E" />
    </View>
  );
}