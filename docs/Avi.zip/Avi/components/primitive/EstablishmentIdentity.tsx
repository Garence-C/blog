import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import ThemedText from "../ThemedText";

type Establishment = EstablishmentsResponse["establishments"][number];

function EstablishmentIdentity({ establishment }: { establishment: Establishment }) {
    return (
        <>
            <ThemedText variant="h2" style={{ fontWeight: "bold" }}>
                {establishment.name}
            </ThemedText>
            <ThemedText variant="regular">
                {establishment.address}, {establishment.city} ({establishment.postCode})
            </ThemedText>
        </>
    );
}

export default EstablishmentIdentity;