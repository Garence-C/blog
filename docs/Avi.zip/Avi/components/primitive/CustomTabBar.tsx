import { router } from "expo-router";
import { MapPinned, Plus, Search } from "lucide-react-native";
import { Text, TouchableWithoutFeedback, View } from "react-native";

export default function CustomTabBar() {
  return (
    <View
      style={{
        backgroundColor: "#F3F3F3",
        height: 78,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        borderTopWidth: 0,
        flexDirection: "row",
        alignItems: "center",
        paddingBottom: 10,
        paddingHorizontal: 32,
      }}
    >
      {/* Search */}
      <TouchableWithoutFeedback onPress={() => router.push("/tabs/searchHotelScreen")}>
        <View style={{ alignItems: "center", gap: 4, width: 62 }}>
          <Search size={24} color="#B9375E" strokeWidth={1.5} />
          <Text style={{ fontSize: 12, fontWeight: "500", color: "#B9375E" }}>
            Rechercher
          </Text>
        </View>
      </TouchableWithoutFeedback>

      {/* Spacer */}
      <View style={{ flex: 1 }} />

      {/* Bouton central */}
      <TouchableWithoutFeedback onPress={() => router.push("/tabs/addEstablishment")}>
        <View
          style={{
            width: 95,
            height: 95,
            borderRadius: 100,
            backgroundColor: "#FFFFFF",
            justifyContent: "center",
            alignItems: "center",
            marginBottom: 18,
            top: -22
          }}
        >
          <View
            style={{
              width: 70,
              height: 70,
              borderRadius: 35,
              backgroundColor: "#B9375E",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Plus size={46} color="#FFFFFF" strokeWidth={1} />
          </View>
        </View>
      </TouchableWithoutFeedback>

      {/* Spacer */}
      <View style={{ flex: 1 }} />

      {/* Map */}
      <TouchableWithoutFeedback onPress={() => router.push("/tabs/map")}>
        <View style={{ alignItems: "center", gap: 4, width: 60 }}>
          <MapPinned size={24} color="#656565" strokeWidth={1.5} />
          <Text style={{ fontSize: 12, fontWeight: "500", color: "#656565" }}>
            Carte
          </Text>
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
}