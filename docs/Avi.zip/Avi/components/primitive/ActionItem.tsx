import React from 'react';
import { Pressable, Text } from 'react-native';

type ActionItemProps = {
  label: string;
  onPress: () => void;
  withBorder?: boolean;
};

export function ActionItem({
  label,
  onPress,
  withBorder = false,
}: ActionItemProps) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingVertical: 8,
        borderBottomWidth: withBorder ? 1.5 : 0,
        borderBottomColor: '#E0E0E0',
      }}
    >
      {({ pressed }) => (
        <Text
          style={{
            fontSize: 18,
            fontWeight: '600',
            opacity: pressed ? 0.5 : 1,
            paddingHorizontal: 3
          }}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}