import { BedDouble, Utensils } from "lucide-react-native";
import { View } from "react-native";
import CustomButton from "./CustomButton";

function EstablishmentTypeBadge({ typeId }: { typeId: number }) {
    return (
        <View style={{ marginRight: "auto" }}>
            {typeId === 1 ? (
                <CustomButton
                    size="small"
                    sizeText="form"
                    type="primary"
                    title="Hôtel"
                    icon={<BedDouble size={16} color="#B9375E" />}
                />
            ) : (
                <CustomButton
                    size="small"
                    sizeText="form"
                    type="primary"
                    title="Restaurant"
                    icon={<Utensils size={16} color="#B9375E" />}
                />
            )}
        </View>
    );
}


export default EstablishmentTypeBadge;