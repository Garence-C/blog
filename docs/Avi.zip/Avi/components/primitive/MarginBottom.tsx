import { View } from "react-native";

type Props = {
    keyboardHeight?: number
}

const BASE_MARGIN_BOTTOM = 150;

export default function Marginbottom({ keyboardHeight = 0 }: Props) {
    return (
        // > 0 ? (BASE_MARGIN_BOTTOM - keyboardHeight) : BASE_MARGIN_BOTTOM
        <View style={{ 
            height: BASE_MARGIN_BOTTOM , 
            backgroundColor: "transparent" 
        }} />
    )
}