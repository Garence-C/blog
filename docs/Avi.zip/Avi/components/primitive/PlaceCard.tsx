import { EqualApproximately, PenLine } from 'lucide-react-native';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import CustomButton from './CustomButton';
import Note from './Note';

export interface Place {
  id: string;
  name: string;
  rating: number;
  type: string;
  latitude: number;
  longitude: number;
  price: string;
  breakfastIncluded?: boolean;
  stageEvening?: boolean;
  dateAdded?: string;
  reviewsCount: number;
  city: string;
  postalCode: string;
}

interface PlaceCardProps {
  place: Place;
  onPress: () => void;
  onReviewPress?: () => void;
}

export default function PlaceCard({ place, onPress, onReviewPress }: PlaceCardProps) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View style={styles.cardContent}>
        <View style={styles.textContainer}>
          <Text style={styles.name}>{place.name}</Text>
          <Text style={styles.city}>{place.city} {"("}{place.postalCode}{")"}</Text>
          <Note 
            notation={place.rating}
            size={8}
            totalOpinions={place.reviewsCount}
          />
          <View style={styles.priceContainer}>
            <View style={styles.priceIcon}>
              <EqualApproximately size={20} color="#000" />
            </View>
            <Text style={styles.price}>{place.price}</Text>
          </View>
        </View>
        <CustomButton
          title={"Écrire un avis"}
          type="primary"
          size="small"
          sizeText="avis"
          icon={<PenLine size={16} color="#B9375E" />}
          onPress={onReviewPress || (() => {})}
        />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    marginLeft: 16,
    marginRight: 16,
    marginBottom: 16,
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
  cardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  textContainer: {
    flex: 1,
    gap: 5,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingLeft: 4,
    paddingTop: 4,
    marginBottom: 16,
  },
  priceIcon: {
    paddingTop: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
  },
  city: {
    fontSize: 13,
    marginBottom: 4,
    fontWeight: '500',
  },
  type: {
    color: '#888',
    fontSize: 12,
  },
  price: {
    color: '#000000',
    fontSize: 18,
    fontWeight: '600',
  },
  reviewButton: {
    backgroundColor: '#FFE0E9',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
  },
  reviewButtonText: {
    color: '#B9375E',
    fontSize: 14,
    fontWeight: '800',
  },
});
