import React from "react";
import { StyleProp, StyleSheet, Text, TextInput, TextInputProps, TextStyle, View } from "react-native";

interface InputProps extends React.ComponentProps<typeof TextInput> { }



type FormInputProps = {
  value: string;
  onChangeText: (text: string) => void;
  onBlur: () => void;
  error?: string;
  newInputStyle?: StyleProp<TextStyle>;
} & Omit<TextInputProps, "value" | "onChangeText" | "onBlur">;

export function FormInput({
  keyboardType,
  value,
  onChangeText,
  onBlur,
  placeholder,
  error,
  secureTextEntry,
  newInputStyle,
  ...props
}: FormInputProps,
) {
  return (
    <View>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        onBlur={onBlur}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        style={[
          styles.input,
          newInputStyle ?? {}, // remplace le style par défaut seulement si fourni
          error && styles.inputError
        ]}
        {...props}
      />
      {error && <View><Text style={styles.error}>{error}</Text></View>}

    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    borderWidth: 1.5,
    borderColor: "#B9375E",
    borderRadius: 10,
    paddingHorizontal: 10,
    fontSize: 13,
    height: 40,
  },
  inputError: {
    borderColor: "red",
  },
  error: {
    color: "red",
    marginTop: 4,
    fontSize: 12,
  },
});
