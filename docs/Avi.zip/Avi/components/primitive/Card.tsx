import { router } from "expo-router";
import { EqualApproximately, PenLine } from "lucide-react-native";
import { Pressable, StyleSheet, Text, View } from "react-native";
import CustomButton from "./CustomButton";
import Note from "./Note";

// Eléments récupérés de la requête API
interface CardItem {
  id: string | number;
  name: string;
  address: string;
  city: string;
  postCode: string;
  countOpinions: number;
  averagePrice: number;
  averageRating: number;
}

// Propriétés du composant Card
interface CardProps {
  item: CardItem;
}

export function Card({ item }: CardProps) {

  return (
    <Pressable
      key={item.id}
      onPress={() => {
        router.push(`/tabs/establishmentSheet/${item.id}`);
      }}
    >
      <View key={item.id} style={styles.card}>
        <View style={styles.content}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.address}>
            {item.address}, {item.city} ({item.postCode})
          </Text>
          <Note
            notation={item.averageRating}
            totalOpinions={item.countOpinions}
          />
          <View style={styles.priceContainer}>
            <View style={styles.priceIcon}>
              {item.countOpinions > 1 && (
                <EqualApproximately size={20} color="#000" />
              )}
            </View>
            <Text style={styles.price}>{`${item.averagePrice}€`}</Text>
          </View>
        </View>
        <CustomButton
          title={"Écrire un avis"}
          type="primary"
          size="small"
          sizeText="avis"
          onPress={() => {
            router.push(`/tabs/establishmentOpinion/create/${item.id}`);
          }}
          icon={<PenLine size={16} color="#B9375E" />}
        />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    borderRadius: 12,
    marginBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#E4E4E4",
  },
  content: {
    flex: 1,
    marginRight: 12,
  },
  name: {
    fontSize: 18,
    fontWeight: 600,
  },
  address: {
    color: "#black",
    marginTop: 4,
    marginBottom: 4,
    fontSize: 13,
    fontWeight: 400,
  },
  price: {
    color: '#000000',
    fontSize: 18,
    fontWeight: '600',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingLeft: 4,
    paddingTop: 4,
    marginBottom: 16,
  },
  priceIcon: {
    display: "flex",
    justifyContent: "center",
  },
});
