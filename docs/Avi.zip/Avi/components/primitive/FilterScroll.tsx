import { X } from "lucide-react-native";
import { StyleSheet, Text, TouchableOpacity } from "react-native";
import { ScrollView } from "react-native-gesture-handler";

type FilterItem = {
    id: string;
    label: string;
    selected: boolean;
    onToggle: () => void;
}

type Props = {
    filters: FilterItem[];
    style: any;
    variant?: "map" | "searchHotelScreen";
};

export default function FilterScroll({ filters, style, variant = "searchHotelScreen" }: Props) {
    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersScroll}
        >
            {filters.map((filter) => (
                <TouchableOpacity
                    key={filter.id}
                    onPress={filter.onToggle}
                    style={[
                        styles.filterButton,
                        filter.selected && styles.filterButtonSelected,
                    ]}
                >
                    <Text
                        style={variant === "map" ? [
                            styles.filterButtonText,
                            filter.selected && styles.filterButtonTextSelected,
                        ] : [ 
                            styles.hFilterButtonText,
                            filter.selected && styles.hFilterButtonTextSelected,
                        ]}
                    >
                        {filter.label}
                    </Text>

                    {filter.selected && <X size={12} color="#B9375E" />}
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
}


const styles = StyleSheet.create({
    filtersScroll: {
        padding: 6,
        paddingTop: 8,
        paddingBottom: 4,
        backgroundColor: '#FFFFFF',
    },
    filterButton: {
        paddingTop: 6,
        paddingBottom: 3,
        paddingLeft: 12,
        paddingRight: 12,
        backgroundColor: '#FFFFFF',
        borderRadius: 8,
        borderWidth: 1.25,
        borderColor: '#B9375E',
        marginRight: 10,
        paddingVertical: 6,
        height: 32,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    filterButtonSelected: {
        backgroundColor: '#FFE0E9',
        borderColor: '#FFE0E9',
    },
    filterButtonText: {
        color: '#B9375E',
        fontSize: 14,
        lineHeight: 18,
        fontWeight: '500',
    },
    hFilterButtonText: {
        color: '#B9375E',
        fontSize: 12,
        lineHeight: 18,
        fontWeight: '500',
    },
    filterButtonTextSelected: {
        backgroundColor: '#FFE0E9',
        fontWeight: '700'
    },
    hFilterButtonTextSelected: {
        backgroundColor: '#FFE0E9',
        fontWeight: '800'
    }
})