import { useRouter } from "expo-router";
import { PenLine } from "lucide-react-native";
import { View } from "react-native";
import CustomButton from "./CustomButton";

type OpinionButtonProps = {
  establishmentId: number;
};


export default function OpinionButton({ establishmentId }: OpinionButtonProps) {
  const router = useRouter();

  return (
    <View style={{ position: "absolute", left: 0, right: 0, bottom: 130, alignItems: "center" }}>
      <CustomButton
        title={"Écrire un avis"}
        type="primary"
        size="small"
        sizeText="avis"
        onPress={() =>
          router.push({
            pathname: "/tabs/establishmentOpinion/create/[id]",
            params: { id: establishmentId.toString() },
          })
        }
        icon={<PenLine size={16} color="#B9375E" />}
      />
    </View>
  );
}
