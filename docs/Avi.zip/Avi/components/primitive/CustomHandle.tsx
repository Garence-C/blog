import { BottomSheetHandleProps } from '@gorhom/bottom-sheet';
import { ChevronUp } from 'lucide-react-native';
import React from 'react';
import { StyleSheet } from 'react-native';
import Animated, { Extrapolate, interpolate, useAnimatedStyle } from 'react-native-reanimated';

export default function CustomHandle({ animatedIndex }: BottomSheetHandleProps) {
    const animatedStyle = useAnimatedStyle(() => {
        const rotation = interpolate(
            animatedIndex.value, 
            [0, 1], 
            [0, 180],
            Extrapolate.CLAMP
        );
        return {
            transform: [{ rotateZ: `${rotation}deg` }],
        };
    });

    return (
    <Animated.View style={[styles.handleContainer, animatedStyle]}>
      <ChevronUp size={24} color="#666" />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  handleContainer: {
    alignItems: 'center',
    paddingVertical: 10,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
});
