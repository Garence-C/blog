import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import { Check } from "lucide-react-native";
import React from "react";
import { Pressable, StyleSheet } from "react-native";

interface CustomCheckboxProps {
  checked?: boolean;
  onCheckedChange?: (value: boolean) => void;
}

export function CustomCheckbox({
  checked = false,
  onCheckedChange,
}: CustomCheckboxProps) {
  const colorScheme = useColorScheme();
  const black = Colors[colorScheme ?? "light"].black;

  const [isChecked, setIsChecked] = React.useState(checked);

  // 🔁 sync si la prop change depuis le parent
  React.useEffect(() => {
    setIsChecked(checked);
  }, [checked]);

  const toggle = () => {
    const next = !isChecked;
    setIsChecked(next);
    onCheckedChange?.(next);
  };

  return (
    <Pressable
      onPress={toggle}
      accessibilityRole="checkbox"
      accessibilityState={{ checked: isChecked }}
      hitSlop={8}
      style={[
        styles.box,
        { borderColor: Colors[colorScheme ?? 'light'].grayDark }
      ]}
    >
      {isChecked && (
        <Check
          size={28}
          color={black}
          strokeWidth={2}
        />
      )}
    </Pressable>
  );
}



const styles = StyleSheet.create({
  box: {
    width: 22,
    height: 22,
    backgroundColor: "white",
    borderWidth: 0.75,
    borderRadius: 4,
    justifyContent: "center",
    alignItems: "center",
  },
});
