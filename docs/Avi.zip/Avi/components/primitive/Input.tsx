import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import React from 'react';
import { StyleSheet, TextInput } from 'react-native';

interface InputProps extends React.ComponentProps<typeof TextInput> {}

export function Input({ ...props }: InputProps) {
  const colorScheme = useColorScheme();

  return (
    <TextInput
      style={[
        styles.input,
        {
          borderColor: Colors[colorScheme ?? 'light'].grayDark,
          color: Colors[colorScheme ?? 'light'].grayDark,
        }
      ]}
      {...props}
    />
  )
}

const styles = StyleSheet.create({
  input: {
    fontFamily: 'RobotoCondended-Regular',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    zIndex: 5,
    borderColor: Colors.light.black, // à supprimer une fois que les ombres eront ajoutées
    borderWidth: 1.75
  }
});
