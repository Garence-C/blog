import { StatusBar } from "expo-status-bar";
import { useColorScheme } from "react-native";


export default function AppStatusBar() {
    const colorScheme = useColorScheme();

    return (
        <StatusBar
            style={colorScheme === "dark" ? "dark" : "dark"}
        />
    )
}