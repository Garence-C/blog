import { FontAwesome } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

export default function Rating({ value = 0, onChange }) {
  return (
    <View style={styles.container}>
      {[1, 2, 3, 4, 5].map((point) => (
        <TouchableOpacity
          key={point}
          onPress={() => onChange?.(point)}
        >
          <FontAwesome
            name={point <= value ? 'circle' : 'circle-thin'}
            size={18}
            color="#E05780"
            style={styles.star}
          />
        </TouchableOpacity>
      ))}
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    marginVertical: 6.5,

  },
  star: {
    marginHorizontal: 2,
  },
});
