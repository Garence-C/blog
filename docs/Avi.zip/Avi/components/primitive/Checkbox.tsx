import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import CheckBox from "expo-checkbox";
import React from "react";

interface CheckboxProps {
  checked?: boolean;
  onCheckedChange?: (value: boolean) => void;
}

export function Checkbox({
  checked = false,
  onCheckedChange,
}: CheckboxProps) {
  const [isChecked, setIsChecked] = React.useState(checked);
  const colorScheme = useColorScheme();

  return (
    <CheckBox
      value={isChecked}
      onValueChange={(value) => {
        setIsChecked(value);
        onCheckedChange && onCheckedChange(value);
      }}
      color={Colors[colorScheme ?? 'light'].black}
      
    />
  )
}
