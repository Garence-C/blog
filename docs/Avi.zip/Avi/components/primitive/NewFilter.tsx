import { X } from "lucide-react-native";
import { useState } from "react";
import { StyleSheet, Text, TouchableOpacity } from "react-native";
import { ScrollView } from "react-native-gesture-handler";

type NewFilterProps = {
  initialSelectedTypes: string;
  initialSelectedFilters: string;
};

export default function NewFilter({ initialSelectedTypes, initialSelectedFilters }: NewFilterProps) {
    const [selectedTypes, setSelectedTypes] = useState<string[]>([initialSelectedTypes]);
    const [selectedFilters, setSelectedFilters] = useState<string[]>([initialSelectedFilters]);

    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersScroll}
        >

            <TouchableOpacity
                onPress={() => {
                    if (selectedTypes.includes('hotel')) {
                        setSelectedTypes(selectedTypes.filter(t => t !== 'hotel'));
                    } else {
                        setSelectedTypes([...selectedTypes, 'hotel']);
                    }
                }}
                style={[styles.filterButton, selectedTypes.includes('hotel') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedTypes.includes('hotel') && styles.filterButtonTextSelected]}>Hôtel</Text>
                {selectedTypes.includes('hotel') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {
                    if (selectedTypes.includes('restaurant')) {
                        setSelectedTypes(selectedTypes.filter(t => t !== 'restaurant'));
                    } else {
                        setSelectedTypes([...selectedTypes, 'restaurant']);
                    }
                }}
                style={[styles.filterButton, selectedTypes.includes('restaurant') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedTypes.includes('restaurant') && styles.filterButtonTextSelected]}>Restaurant</Text>
                {selectedTypes.includes('restaurant') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {
                    if (selectedFilters.includes('bestRated')) {
                        setSelectedFilters(selectedFilters.filter(f => f !== 'bestRated'));
                    } else {
                        setSelectedFilters([...selectedFilters, 'bestRated']);
                    }
                }}
                style={[styles.filterButton, selectedFilters.includes('bestRated') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedFilters.includes('bestRated') && styles.filterButtonTextSelected]}>Le mieux noté</Text>
                {selectedFilters.includes('bestRated') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {
                    if (selectedFilters.includes('breakfastIncluded')) {
                        setSelectedFilters(selectedFilters.filter(f => f !== 'breakfastIncluded'));
                    } else {
                        setSelectedFilters([...selectedFilters, 'breakfastIncluded']);
                    }
                }}
                style={[styles.filterButton, selectedFilters.includes('breakfastIncluded') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedFilters.includes('breakfastIncluded') && styles.filterButtonTextSelected]}>Petit déjeuner inclus</Text>
                {selectedFilters.includes('breakfastIncluded') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {
                    if (selectedFilters.includes('stageEvening')) {
                        setSelectedFilters(selectedFilters.filter(f => f !== 'stageEvening'));
                    } else {
                        setSelectedFilters([...selectedFilters, 'stageEvening']);
                    }
                }}
                style={[styles.filterButton, selectedFilters.includes('stageEvening') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedFilters.includes('stageEvening') && styles.filterButtonTextSelected]}>Soirée étape</Text>
                {selectedFilters.includes('stageEvening') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {
                    if (selectedFilters.includes('mostRecent')) {
                        setSelectedFilters(selectedFilters.filter(f => f !== 'mostRecent'));
                    } else {
                        setSelectedFilters([...selectedFilters, 'mostRecent']);
                    }
                }}
                style={[styles.filterButton, selectedFilters.includes('mostRecent') && styles.filterButtonSelected]}
            >
                <Text style={[styles.filterButtonText, selectedFilters.includes('mostRecent') && styles.filterButtonTextSelected]}>Le plus récent</Text>
                {selectedFilters.includes('mostRecent') && <X size={12} color="#B9375E" />}
            </TouchableOpacity>

        </ScrollView>
    )
}


const styles = StyleSheet.create({
    filtersScroll: {
        padding: 10,
        paddingTop: 8,
        paddingBottom: 4,
        backgroundColor: '#FFFFFF',
    },
    filterButton: {
        paddingTop: 6,
        paddingBottom: 3,
        paddingLeft: 12,
        paddingRight: 12,
        backgroundColor: '#FFFFFF',
        borderRadius: 8,
        borderWidth: 1.25,
        borderColor: '#B9375E',
        marginRight: 10,
        paddingVertical: 6,
        height: 32,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    filterButtonSelected: {
        backgroundColor: '#FFE0E9',
        borderColor: '#FFE0E9',
    },
    filterButtonText: {
        color: '#B9375E',
        fontSize: 14,
        lineHeight: 18,
        fontWeight: '500',
    },
    filterButtonTextSelected: {
        backgroundColor: '#FFE0E9',
        fontWeight: '700'
    },
})