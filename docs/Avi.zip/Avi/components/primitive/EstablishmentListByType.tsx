import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import React from "react";
import { FlatList, Text } from "react-native";
import { Card } from "./Card";
import { Loader } from "./Loader";


export type EstablishmentListByTypeProps = {
  establishmentList: EstablishmentsResponse["establishments"];
};


function EstablishmentListByType({ establishmentList }: EstablishmentListByTypeProps)  {

  if (!establishmentList) {
    return <Loader />
  }

  return (
    <FlatList
      data={establishmentList}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <Card
          item={{
            id: item.id,
            name: item.name,
            address: item.address,
            city: item.city,
            postCode: item.postCode,
            countOpinions: item.countOpinions,
            averagePrice: item.averagePrice,
            averageRating: item.averageRating,
          }}
        />
      )}
      ListEmptyComponent={
        <Text style={{ textAlign: "center", marginTop: 20 }}>
          Aucun établissement trouvé
        </Text>
      }
    />
  );
}

export default EstablishmentListByType;