import { Image, StyleSheet, View } from "react-native";


export default function ShowPhotos() {
    return (
        <View style={styles.container}>
            <Image
                style={styles.mainPhoto}
                source={require('@/assets/images/restotest/img-1.webp')}
                resizeMode="cover"

            />
            <View style={styles.rightContainer}>
                <Image
                    style={styles.otherPhoto}
                    source={require('@/assets/images/restotest/img-2.jpg')}
                    resizeMode="cover"

                />
                <Image
                    style={styles.otherPhoto}
                    resizeMode="cover"
                    source={require('@/assets/images/restotest/img-3.jpg')}
                />
            </View>
        </View>
    )
}

const MAX_HEIGHT = 150;
const GAP = 10;

const styles = StyleSheet.create({
    // Mécanisme de CSS GRID sous forme de FLEX
    container: {
        display: "flex",
        flexDirection: "row",
        width: "100%",
        height: MAX_HEIGHT,
        // backgroundColor: "blue",
        gap: GAP,
        marginBottom: 4
    },
    mainPhoto: {
        // backgroundColor: "lightgray",
        height: "100%",
        flex: 2
    },
    rightContainer: {
        display: "flex",
        flexDirection: "column",
        gap: GAP,
        flex: 1
    },
    otherPhoto: {
        flex: 1,
        width: "100%"
    }
})