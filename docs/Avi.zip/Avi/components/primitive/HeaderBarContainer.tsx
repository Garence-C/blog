import { View } from "react-native";


export default function HeaderBarContainer({children}: React.PropsWithChildren) {
    return (
        <View style={{ marginLeft: 15, marginRight: 23 }}>
            {children}
        </View>
    )
}