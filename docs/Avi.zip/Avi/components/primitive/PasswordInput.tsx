import { Input } from "@/components/primitive/Input";
import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import { Eye, EyeOff } from "lucide-react-native";
import React from "react";
import { Pressable, StyleSheet, View } from "react-native";

export function PasswordInput({ ...props }: React.ComponentProps<typeof Input>) {
  const colorScheme = useColorScheme();
  const [showPassword, setShowPassword] = React.useState(false);

  return (
    <View style={styles.container}>
      <Input
        {...props}
        secureTextEntry={!showPassword}
      />
      <Pressable
        style={styles.button}
        onPress={() => setShowPassword(prev => !prev)}
      >
        {showPassword ? (
          <EyeOff size={20} color={Colors[colorScheme ?? 'light'].grayDark} />
        ) : (
          <Eye size={20} color={Colors[colorScheme ?? 'light'].grayDark} />
        )}
      </Pressable>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  button: {
    position: 'absolute',
    top: '50%',
    right: 10,
    transform: [{ translateY: '-50%' }],
    zIndex: 10,
    elevation: 10,
    padding: 8
  },
});
