import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';


type CustomButtonProps = {
  title: string;
  onPress?: () => void;
  disabled?: boolean;
  type?: 'primary' | 'secondary' | 'connexion';
  size?: 'small' | 'large' | 'form';
  sizeText?: 'smallText' | 'largeText' | 'avis' | 'connexion' | 'form';
  iconPlacement?: 'start' | 'end';
  icon?: React.ReactNode;
};

const CustomButton: React.FC<CustomButtonProps> = ({
  title,
  onPress,
  disabled = false,
  type = "primary",
  size = 'large',
  sizeText = 'largeText',
  iconPlacement = 'start',
  icon
}) => {
  const getSize = () => {
    switch (size) {
      case 'large':
        return styles.large
      case 'small':
        return styles.small
      case 'form':
        return styles.form
    }
  }
  const getTextStyle = () => {
    switch (sizeText) {
      case 'smallText':
        return styles.smallText;
      case 'largeText':
        return styles.largeText;
      case 'avis':
        return styles.avisText;
      case 'connexion':
        return styles.connexionText;
      case 'form':
        return styles.formText
    }
  }
  const getType = () => {
    switch (type) {
      case 'primary':
        return styles.primary;
      case 'secondary':
        return styles.secondary;
      case 'connexion':
        return styles.connexion;
    }
  }
  return (
    <TouchableOpacity
      style={[
        styles.button,
        getType(),
        getSize(),
        disabled && styles.disabled
      ]}
      onPress={!disabled ? onPress : undefined}
      disabled={disabled}

    >
      <View style={styles.content}>
        {icon && type !== 'connexion' && <View style={styles.icon}>{icon}</View>}
        <Text
          style={[
            styles.text,
            getTextStyle()
          ]}
        >
          {title}
        </Text>
        {icon && type === 'connexion' && <View style={styles.iconLeft}>{icon}</View>}
        {iconPlacement === "end" ? (
          <View style={styles.icon}>{icon}</View>
        ) : null}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  primary: {
    backgroundColor: '#FFE0E9',
    borderColor: '#FFE0E9',
    borderWidth: 1.25
  },
  secondary: {
    backgroundColor: '#FFFFFF',
    borderColor: '#B9375E',
    borderWidth: 1.25
  },
  connexion: {
    height: 40,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 18,
    backgroundColor: '#B9375E',
    fontFamily: "RobotoCondensed-Medium",
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: "bold"
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 18,
    alignItems: 'flex-start',
    justifyContent: 'center'
  },
  text: {
    fontFamily: "RobotoCondensed-Medium",
    color: '#B9375E',
    fontSize: 16
  },
  large: {
    paddingVertical: 10,
    alignItems: 'center',
    paddingHorizontal: 20,
    minWidth: 140,

  },
  small: {
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 10,
  },
  form: {
    paddingVertical: 8,
    paddingHorizontal: 10,
    marginRight: 20,
    borderRadius: 10
  },
  largeText: {
    fontSize: 22,
    fontWeight: "bold",
    lineHeight: 30,
  },
  smallText: {
    fontSize: 12,
    minHeight: 14,
    includeFontPadding: false,
    textAlignVertical: 'center'
  },
  connexionText: {
    fontFamily: "RobotoCondensed-Medium",
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: "bold",
    textAlign: 'left',
    flex: 1,
    height: 25
  },
  avisText: {
    fontSize: 12,
    minHeight: 14,
    fontWeight: 700,
    includeFontPadding: false,
    textAlign: 'center'
  },
  formText: {
    fontSize: 12,
    minHeight: 14,
    fontWeight: 700,
    includeFontPadding: false,
    textAlignVertical: 'center'
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  icon: {
    marginRight: 6,
  },
  iconLeft: {
    marginLeft: 'auto'
  },
  disabled: {
    opacity: 0.5,
  }
});

export default CustomButton;
