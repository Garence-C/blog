import { EstablishmentByIdResponse } from "@/constants/api/functions/establishment";
import { Ellipsis } from "lucide-react-native";
import { useState } from "react";
import { Pressable, View } from "react-native";
import ThemedText from "../ThemedText";
import { Back } from "./Back";
import BottomSheetDecompo from "./EditingBottomSheet";

interface HeaderBarProps {
    title?: string;
    menuIsActive?: boolean;
    establishment?: EstablishmentByIdResponse
    onCallEstablishment?: () => void;
    onSendMail?: () => void;
    onGoThere?: () => void;
}

function HeaderBar({ title, menuIsActive = false, establishment, onCallEstablishment, onSendMail, onGoThere }: HeaderBarProps) {
    const [openEstablishment, setOpenEstablishment] = useState(false);
    return (
        <View style={{ flexDirection: "row", justifyContent: "space-between"}}> 
        {/* , marginLeft: 15, marginRight: 25 */}
            {/* Back à gauche */}
            <View style={{ justifyContent: "center" }}>
                <Back />
            </View>

            {/* Texte optionnel centré */}
            {title ? (
                <View style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                    // width: '100%'
                }}>
                    <ThemedText variant="h2" style={{ textAlign: "center" }}>
                        {title}
                    </ThemedText>
                </View>
            ) : (
                <View style={{ flex: 1 }} />
            )}

            {/* Ellipsis à droite */}
            {menuIsActive ? (
                <>
                    <Pressable style={{ justifyContent: "center" }} onPress={() => setOpenEstablishment(true)}>
                        <Ellipsis size={28} strokeWidth={1} />
                    </Pressable>
                    <BottomSheetDecompo visible={openEstablishment} type='establishment' onClose={() => setOpenEstablishment(false)} establishmentData={establishment} onCallEstablishment={onCallEstablishment} onSendMail={onSendMail} onGoThere={onGoThere} />
                </>
                
            ) : <View style={{ width: 28 }} />} 
        </View>
    );
}

export default HeaderBar;
