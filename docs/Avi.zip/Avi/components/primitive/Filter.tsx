import { useState } from "react";
import { StyleSheet, View } from "react-native";
import CustomButton from "./CustomButton";

type FilterProps = {
  name: string;
};


export default function Filter ({name}: FilterProps) {
    const [isSelected, setIsSelected] = useState(false)
    return (
        <View 
            style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                gap: 4,
                paddingHorizontal: 4,
                paddingVertical: 8
            }}
        >
            <CustomButton 
                title={name} 
                size="small"
                sizeText='smallText'
                onPress={() => {	
                    setIsSelected(!isSelected)
                }}
                type={isSelected ? "primary" : "secondary"}
            />
        </View>
)}


const styles = StyleSheet.create({
  filters: { 
    marginTop: 16,
  }
})