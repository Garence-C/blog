import { EstablishmentByIdResponse } from '@/constants/api/functions/establishment';
import { useRouter } from 'expo-router';
import React from 'react';
import {
  Animated,
  Dimensions,
  PanResponder,
  StyleSheet,
  View
} from 'react-native';
import Modal from 'react-native-modal';
import { ActionItem } from './ActionItem';

const SCREEN_HEIGHT = Dimensions.get('window').height;

type SheetType = 'review' | 'establishment';

type Props = {
  visible: boolean;
  onClose: () => void;
  type: SheetType;
  onEditReview?: () => void;
  onDeleteReview?: () => void;
  onCallEstablishment?: () => void;
  onSendMail?: () => void;
  onGoThere?: () => void;
  establishmentData?: EstablishmentByIdResponse
};

export default function BottomSheetDecompo({
  visible,
  onClose,
  type,
  onEditReview,
  onDeleteReview,
  onCallEstablishment,
  onSendMail,
  onGoThere,
  establishmentData
}: Props) {

  const router = useRouter();

  /** Gestion de la hauteur */
  const sheetHeight =
    type === 'establishment'
      ? SCREEN_HEIGHT * 0.25
      : SCREEN_HEIGHT * 0.15;


  const translateY = React.useRef(
    new Animated.Value(sheetHeight)
  ).current;

  /** Actions */

  const handleEditReview = () => {
    console.log('Modifier mon avis');
    onEditReview?.();
    onClose();
  };

  const handleDeleteReview = () => {
    console.log('Supprimer mon avis');
    onDeleteReview?.();
    onClose();
  };

  const handleCall = () => {
    console.log("Appeler l'établissement ?");
    onCallEstablishment?.();
    onClose();
  };

  const handleMail = () => {
    console.log('Envoyer un mail');
    onSendMail?.();
    onClose();
  };

  const handleNavigate = () => {
    console.log("S'y rendre");
    onGoThere?.();
    onClose();
  };

  const handleEditPlace = () => {
    if (!establishmentData?.establishment.id) return;

    console.log('Modifier la fiche');
    onClose();
    router.push({
      pathname: "/establishment/edit/[id]",
      params: {
        id: establishmentData?.establishment.id.toString()
        // TODO : envoyer le reste des paramètres
      }
    })
  };

  /** Config DATA-DRIVEN */

  const actionsByType: Record<SheetType, { label: string; onPress: () => void }[]> = {
    review: [
      { label: 'Modifier mon avis', onPress: handleEditReview },
      { label: 'Supprimer mon avis', onPress: handleDeleteReview },
    ],
    establishment: [
      { label: 'Appeler', onPress: handleCall },
      { label: 'Envoyer un mail', onPress: handleMail },
      { label: "S'y rendre", onPress: handleNavigate },
      { label: 'Modifier la fiche', onPress: handleEditPlace },
    ],
  };

  /** Animation */

  React.useEffect(() => {
    if (visible) {
      Animated.timing(translateY, {
        toValue: 0,
        duration: 280,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);

  const panResponder = React.useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dy > 10,
      onPanResponderMove: (_, g) => {
        if (g.dy > 0) translateY.setValue(g.dy);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > sheetHeight / 3) {
          onClose();
        } else {
          Animated.timing(translateY, {
            toValue: 0,
            duration: 200,
            useNativeDriver: true,
          }).start();
        }
      },
    })
  ).current;

  /** Render */

  const actions = actionsByType[type];

  return (
    <Modal
      isVisible={visible}
      onBackdropPress={onClose}
      style={styles.modal}
      backdropColor="white"
      backdropOpacity={0.75}
    // backgroundStyle={{ backgroundColor: '#F2F2F2'}}     POUR UNIFIER AVEC LA COULEUR DE LA BARRE ANDROID
    >
      <Animated.View
        style={[styles.sheet, { height: sheetHeight, transform: [{ translateY }] }]}
        {...panResponder.panHandlers}
      >
        <View style={styles.handle} />

        <View style={styles.container}>
          {actions.map((action, index) => (
            <ActionItem
              key={action.label}
              label={action.label}
              onPress={action.onPress}
              withBorder={index < actions.length - 1}
            />
          ))}
        </View>
      </Animated.View>
    </Modal>
  );
}


const styles = StyleSheet.create({
  modal: {
    justifyContent: 'flex-end',
    margin: 0,
    paddingBottom: 10
  },
  sheet: {
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 20,
  },
  handle: {
    width: 60,
    height: 3,
    backgroundColor: '#ccc',
    borderRadius: 3,
    alignSelf: 'center',
    marginVertical: 10,
  },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 10,
  }
});

