import { Colors } from "@/constants/Colors";
import { useColorScheme } from "@/hooks/useColorScheme";
import { useSearchHistory } from "@/hooks/utils/useSearchHistory";
import * as Location from "expo-location";
import { useRouter } from "expo-router";
import { MapPin, Search, X } from "lucide-react-native";
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

type SearchBarProps = {
  title: string;
  type?: "default" | "button";
}

export type SearchHistoryItem = {
  label: string;
  timestamp: number;
};


export function SearchBar({ title, type = "default" }: SearchBarProps) {
  const colorScheme = useColorScheme();
  const router = useRouter();

  const [isFocused, setIsFocused] = useState(false);
  const { history, addSearch } = useSearchHistory();

  const [value, setValue] = React.useState("");
  const clearText = () => setValue("");

  const [city, setCity] = useState("");
  const [postCode, setPostCode] = useState("");

  const [shouldSearch, setShouldSearch] = useState(false);

  const onSubmit = () => {
    if (!value.trim()) return;

    addSearch(value); // ajoute à la recherche à l'historique

    router.push({
      pathname: "/tabs/resultSearchScreen",
      params: { query: value },
    });
  }

  if (type === "button") {
    return (
      <Pressable
        style={styles.buttonContainer}
        onPress={() => router.push("/tabs/searchScreen")}
      >
        <Search size={24} color="black" style={[styles.searchIcon]} />
        <TextInput
          editable={false}
          pointerEvents="none"
          style={[
            styles.input,
            {
              borderColor: Colors[colorScheme ?? "light"].grayDark,
              color: Colors[colorScheme ?? "light"].grayDark,
            },
          ]}
          placeholder={title}
          placeholderTextColor="black"
        />
      </Pressable>
    );
  }

  const getUserLocation = async () => {
    try {
      // Demande de permission
      const { status } = await Location.requestForegroundPermissionsAsync()
      if (status !== 'granted') return false;

      // Récupération de la position
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
        timeInterval: 1000,
      })

      console.log('Latitude:', location.coords.latitude)
      console.log('Longitude:', location.coords.longitude)

      // Reverse Geocoding pour récupérer la ville et code postal
      const addressData = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      if (!addressData.length) return false;
      
      const data = addressData[0];

      setCity(data.city || '');
      setPostCode(data.postalCode || '');

      const fullAddress = [data.name, data.street, data.city]
        .filter(Boolean)
        .join(', ');
      setValue(fullAddress);

      return true; 

    } catch (error) {
      console.log('Erreur GPS:', error)
      return false;
    }
  };

  useEffect(() => {
    if (!shouldSearch) return;
    if (!value || !city || !postCode) return;

    addSearch(value);

    router.push({
      pathname: "/tabs/resultSearchScreen",
      params: { query: value },
    });

    setShouldSearch(false);
  }, [shouldSearch, value, city, postCode]);

  return (
    <>
      <View style={styles.searchBarContainer}>
        <View style={styles.container}>
          <View style={styles.textInputContainer}>
            <Pressable onPress={onSubmit} style={styles.searchIcon}>
              <Search size={20} color="black" />
            </Pressable>
            <TextInput
              value={value}
              onChangeText={setValue}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              returnKeyType="search"
              onSubmitEditing={onSubmit}
              style={[
                styles.input,
                {
                  borderColor: Colors[colorScheme ?? "light"].grayDark,
                  color: Colors[colorScheme ?? "light"].grayDark,
                },
              ]}
              placeholder={title}
              placeholderTextColor="black"

            />
            <Pressable onPress={clearText}>
              <X size={20} color="black" />
            </Pressable>
          </View>
          <View style={{ position: 'absolute', right: 10 }}>
            <Pressable onPress={() => router.push("/tabs/searchHotelScreen")}>
              <Text style={{ textDecorationLine: 'underline', fontWeight: '500' }}>Annuler</Text>
            </Pressable>
          </View>
        </View>
      </View>
      <ScrollView >
        <View style={[styles.results]}>
          <TouchableOpacity style={styles.myPosition}>
            <Pressable
              style={styles.button}
              onPress={async () => {
                const success = await getUserLocation();

                if (!success) {
                  alert("Impossible de récupérer la localisation");
                  return;
                }

                setShouldSearch(true);
              }}
            >
              <MapPin size={24} />
              <Text style={[styles.texts]}>Ma position</Text>
            </Pressable>
          </TouchableOpacity>
        </View>

        {history.length > 0 && (
          <View style={[styles.results]}>

            {history.map((item, index) => (
              <TouchableOpacity style={styles.myPosition} key={index}>
                <Pressable
                  key={item.timestamp}
                  style={styles.button}
                  onPress={() => {
                    setValue(item.label);
                    addSearch(item.label);
                    router.push({
                      pathname: "/tabs/resultSearchScreen",
                      params: { query: item.label },
                    });
                  }}
                >
                  <MapPin size={24} color={"white"} />
                  <Text style={[styles.texts]}>{item.label}</Text>
                </Pressable>
              </TouchableOpacity>

            ))}
          </View>
        )}
      </ScrollView>
    </>
  );
}
const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 26,
  },
  searchBarContainer: {
    backgroundColor: "#FFFFFF",
    marginBottom: 16,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#E4E4E4",
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderColor: Colors.light.black, // à supprimer une fois que les ombres seront ajoutées
    borderWidth: 2,
    marginTop: 26,

  },
  button: {
    display: "flex",
    flexDirection: "row",
    width: 'auto'
  },
  textInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderColor: Colors.light.black, // à supprimer une fois que les ombres eront ajoutées
    borderWidth: 2,
    marginRight: 58,
  },
  searchIcon: {
    padding: 4
  },
  input: {
    flex: 1,
    fontFamily: 'RobotoCondended-Regular',
    paddingHorizontal: 12,
    paddingVertical: 0,
    height: 38,
    borderRadius: 20,
    zIndex: 5,
  },
  myPosition: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 20,
    paddingVertical: 7,
  },
  texts: {
    marginLeft: 8,
    fontSize: 17,
    flex: 1
  },
  searchHistory: {
    marginLeft: 26,

  },
  textHistory: {
    fontSize: 17,
    paddingVertical: 7
  },
  results: {
    marginTop: 0,
  },

});