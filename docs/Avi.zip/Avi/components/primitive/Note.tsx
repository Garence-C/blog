import { StyleSheet, Text, View } from "react-native";
import Etoile from "./Etoile";

export interface NoteProps {
  notation: number; // Note moyenne à afficher (de 0 à 5)
  size?: number; // Taille des étoiles
  totalOpinions?: number; // Nombre total d'avis
  totalOpinionsStyle?: "normal" | "underline" // Souligne ou non le texte des avis
}
const Note = ({ notation, size = 7, totalOpinions, totalOpinionsStyle }: NoteProps) => {
  const isOpinions = totalOpinions || 0;

  return (
    <View style={styles.container}>
      <Etoile
        type={notation > 0 ? true : false}
        size={size}
      />
      <Etoile
        type={notation > 1 ? true : false}
        size={size}

      />
      <Etoile
        type={notation > 2 ? true : false}
        size={size}

      />
      <Etoile
        type={notation > 3 ? true : false}
        size={size}

      />
      <Etoile
        type={notation > 4 ? true : false}
        size={size}
      />
      {/* TODO : A CORRIGER car pas afficher pour la page détail établissement*/}

      {totalOpinionsStyle === "underline" ? (
        <Text style={{ textDecorationLine: "underline" }}>
          {isOpinions > 0 ? `(${isOpinions} avis)` : ""}
        </Text>
      ) : (
      <Text>
        {isOpinions > 0 ? `(${isOpinions} avis)` : ""}
      </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    gap: 4
  }
});

export default Note;