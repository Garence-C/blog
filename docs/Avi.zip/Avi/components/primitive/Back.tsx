import { FontAwesome6 } from "@expo/vector-icons";
import { router } from "expo-router";
import { Pressable, StyleSheet, View } from "react-native";

export function Back () {
    return (
        <View  >
            <Pressable onPress={() => router.push('/tabs/searchHotelScreen')} style={styles.container}>
                <FontAwesome6
                    name={'angle-left'}
                    size={18}
                    color="black"
                />
            </Pressable>
        </View>
)}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12
  }
})