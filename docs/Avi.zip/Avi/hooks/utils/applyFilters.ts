import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";

export function applyFilters(
    establishments: EstablishmentsResponse["establishments"],
    selectedFilters: string[]
) {
    let result = [...establishments];

    if (selectedFilters.includes("bestRated")) {
        result.sort((a, b) => (b.averageRating ?? 0) - (a.averageRating ?? 0));
    }

    if (selectedFilters.includes("mostRecent")) {
        result.sort(
            (a, b) => 
                new Date(b.createdAt).getTime() - 
                new Date(a.createdAt).getTime()
        );
    }

    if (selectedFilters.includes("breakfast")) {
        result = result.filter(
            (e) => e.breakfast === true
        );
    }

    if (selectedFilters.includes("stageEvening")) {
        result = result.filter(
            (e) => e.stageEvening === true
        );
    }

    if (selectedFilters.includes("midday")) {
        result = result.filter(
            (e) => e.midday === true
        );
    }

    if (selectedFilters.includes("evening")) {
        result = result.filter(
            (e) => e.evening === true
        );
    }

    if (selectedFilters.includes("price")) {
        result.sort((a, b) => (a.averagePrice ?? 0) - (b.averagePrice ?? 0));
    }

    return result;

}