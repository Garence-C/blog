import { useMemo } from "react";
import { useEstablishments } from "../tanStack/useEstablishments";

type useSearchEstablishmentsProps = {
    query?: string
}

export function useSearchEstablishments({ query }: useSearchEstablishmentsProps) {
    const { data } = useEstablishments();
    const search = query?.trim().toLowerCase() ?? "";

    const normalize = (text: string) =>
        text
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");

    const filteredEstablishments = useMemo(() => {
        if (!data) return [];

        const priorityList: { item: typeof data.establishments[0]; totalPoints: number }[] = [];

        const regExExactPostCode = /^(?:0[1-9]|[1-8]\d|9[0-8])\d{3}$/;
        const regExPartialPostCode = /^(?:0[1-9]|[1-8]\d|9[0-8])\d{0,3}$/;

        // Système de points
        const exactName = 100;
        const exactPostCode = 80;
        const exactCity = 80;
        const exactAdress = 60;
        const partialCity = 40;
        const partialName = 50;
        const partialPostCode = 20;
        const partialAddress = 30;

        const q = normalize(search);

        console.log("---------------------- Nouvelle recherche -------------------")
        for (const item of data.establishments) {
            let totalPoints = 0;
            const name = normalize(item.name);
            const city = normalize(item.city);
            const address = normalize(item.address);
            const postCode = item.postCode; // garder chiffres bruts

            // Nom
            if (name === q) totalPoints += exactName;
            else if (name.includes(q)) totalPoints += partialName;

            // Ville
            if (city === q) totalPoints += exactCity;
            else if (city.includes(q)) totalPoints += partialCity;

            // Code postal
            if (postCode === q && regExExactPostCode.test(q)) totalPoints += exactPostCode;
            else if (regExPartialPostCode.test(q)) totalPoints += partialPostCode;

            // Adresse
            if (address === q) totalPoints += exactAdress;
            else if (address.includes(q)) totalPoints += partialAddress;

            // On conserve uniquement si le nombre de points total est supérieur à 0
            if (totalPoints > 0) {
                priorityList.push({ item, totalPoints });
                console.log(`search="${q}", name=${item.name}, city=${item.city}, postCode=${postCode}, address=${item.address}, totalPoints=${totalPoints}`)
            }
        }

        if(priorityList.length === 0) {
            console.log("Aucun résultat de recherche trouvé pour : ", search)
        }

        // Tri par score décroissant
        return priorityList.sort((a, b) => b.totalPoints - a.totalPoints).map(p => p.item);
    }, [data, search]);

    return filteredEstablishments;
}
