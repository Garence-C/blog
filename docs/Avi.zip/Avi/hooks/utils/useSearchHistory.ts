import { SearchHistoryItem, getSearchHistory, saveSearch } from "@/utils/searchHistory";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";

const SEARCH_HISTORY_KEY = process.env.SEARCH_HISTORY_KEY;

export function useSearchHistory() {
    const [history, setHistory] = useState<SearchHistoryItem[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSearchHistory().then(data => {
            setHistory(data);
            setLoading(false);
        });
    }, []);

    const addSearch = async (input: string) => {
        await saveSearch(input);
        const updated = await getSearchHistory();
        setHistory(updated);
    };

    const clearHistory = async () => {
        await AsyncStorage.removeItem(SEARCH_HISTORY_KEY);
        setHistory([]);
    };

    return {
        history,
        loading,
        addSearch,
        clearHistory,
    };
}


export default useSearchHistory;