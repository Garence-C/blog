import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import { useMemo } from "react";

type useFilteredEstablishmentsByTypeProps = {
    allEstablishments?: EstablishmentsResponse,
    isHotel: boolean
}

export function useFilteredEstablishmentsByType({allEstablishments, isHotel}: useFilteredEstablishmentsByTypeProps) {
    const filteredEstablishments = useMemo(() => {
            if (!allEstablishments) return [];
            
            return allEstablishments.establishments.filter((e) =>
                isHotel ? e.typeId === 1 : e.typeId === 2
            );
        }, [allEstablishments, isHotel]);

    return filteredEstablishments;
}

export default useFilteredEstablishmentsByType;