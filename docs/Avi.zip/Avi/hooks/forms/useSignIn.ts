import { useForm } from "react-hook-form";
import { useLoginUser } from "../tanStack/useLoginUser";

export type UserFormValue = {
    email: string;
    password: string;
}

type SignIn = {
    mode: "login";
    onSuccess?: () => void;
}

export function useSingIn({
    mode,
    onSuccess
}: SignIn) {
    // Constante
    const EMPTY_VALUES: UserFormValue = {
        email: "",
        password: ""
    }

    // Formulaire de base
    const form = useForm<UserFormValue>({
        mode: "onBlur",
        defaultValues: {
            email: EMPTY_VALUES.email,
            password: EMPTY_VALUES.password
        }
    })

    // Déstructure l'objet
    const { reset, handleSubmit } = form;

    // Hook personnalisé
    const loginMutation = useLoginUser()

    const isLoading = loginMutation.isPending;
    const submitLabel = "Connexion";

    const submit = handleSubmit((data) => {
        const payload = {
            email: data.email,
            password: data.password
        }

        if (mode === "login") {
            loginMutation.mutate(payload, {
                onSuccess: () => {
                    reset(EMPTY_VALUES);
                }
            })
        }
    })

    return {
        form,
        submit,
        submitLabel,
        isLoading
    }

}
