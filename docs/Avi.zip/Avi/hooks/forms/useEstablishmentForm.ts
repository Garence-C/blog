import { EstablishmentFormValue } from "@/components/forms/add-establishment-form";
import { useState } from "react";

export function useEstablishmentForm(
    initial?: Partial<EstablishmentFormValue>
) {
    const [value, setValue] = useState<EstablishmentFormValue>({
        name: "",
        city: "",
        postCode: "",
        longitude: "123",
        latitude: "-123",
        address: "",
        tel: "",
        email: "",
        typeId: null,
        ...initial
    })

    const onChange = (next: Partial<EstablishmentFormValue>) => {
        setValue((prev) => ({ ...prev, ...next }))
    }

    const reset = () => {
        setValue({
            name: "",
            city: "",
            postCode: "",
            longitude: "123",
            latitude: "-123",
            address: "",
            tel: "",
            email: "",
            typeId: null,
        })
    }

    return {
        value,
        onChange,
        reset,
    };
}