import { OpinionFormValue } from "@/components/forms/OpinionForm";
import { useFocusEffect } from "expo-router";
import { useCallback, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useCreateOpinion } from "../tanStack/useCreateOpinion";
import { useUpdateOpinion } from "../tanStack/useUpdateOpinion";

type useOpinionFormProps = {
  mode: "create" | "edit";
  establishmentId: number;
  opinion?: {
    id: string;
    price?: string;
    rating?: number | null;
    commentary?: string;
  };
  onSuccess?: () => void;
}

export function useOpinionForm({
  mode,
  establishmentId,
  opinion,
  onSuccess
}: useOpinionFormProps) {
  // Constante
  const EMPTY_VALUES: OpinionFormValue = {
    price: "",
    rating: null,
    commentary: ""
  }

  // Formulaire de base
  const form = useForm<OpinionFormValue>({
    mode: "onBlur",
    defaultValues: {
      price: EMPTY_VALUES.price,
      rating: EMPTY_VALUES.rating,
      commentary: EMPTY_VALUES.commentary,
    },
  })

  // Déstructure l'objet form
  const { reset, handleSubmit } = form;

  // Hooks personnalisés
  const createMutation = useCreateOpinion(establishmentId);
  const updateMutation = useUpdateOpinion(establishmentId);

  const isLoading = createMutation.isPending || updateMutation.isPending;
  const submitLabel = mode === "edit" ? "Modifier mon avis" : "Ajouter un avis";

  // Réinitalisation du formulaire lorsqu'il est en mode CREATE
  useFocusEffect(
    useCallback(() => {
      if (mode === "create") {
        reset({
          price: EMPTY_VALUES.price,
          rating: EMPTY_VALUES.rating,
          commentary: EMPTY_VALUES.commentary,
        })
      }
    }, [mode, reset]
    )
  )

  // Recharge les valeurs des champs en mode EDIT
  useEffect(() => {
    if (mode !== "edit" || !opinion) return;

    reset({
      price: opinion.price ?? EMPTY_VALUES.price,
      rating: Number(opinion.rating) ?? EMPTY_VALUES.rating,
      commentary: opinion.commentary ?? EMPTY_VALUES.commentary,
    });

  }, [
    mode,
    opinion?.id,
    reset,
  ])

  const submit = handleSubmit((data) => {
    const payload = {
      price: Number(data.price),
      rating: Number(data.rating),
      commentary: data.commentary,
    }

    if (mode === "create") {
      createMutation.mutate(payload, {
        onSuccess: () => {
          reset(EMPTY_VALUES); // réinitalise les champs 
          onSuccess?.()
        }
      })
    }

    if (mode === "edit" && opinion?.id) {
      updateMutation.mutate(
        { id: opinion.id, data: payload },
        { onSuccess }
      )
    }
  })

  return {
    form,
    submit,
    submitLabel,
    isLoading
  }

}