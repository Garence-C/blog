import { clearToken } from '@/constants/api/client';
import { useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';

/**
 * Déconnecte l'utilisateur de l'applciation dès qu'il la ferme.
 * @returns 
 */
export function useAuthHandler() {
    const queryClient = useQueryClient();
    const router = useRouter();

    const handleLogout = async () => {
        await clearToken();
        queryClient.removeQueries({ queryKey: ['currentUser'] });
        router.replace('/sign-in');
    };

    return { handleLogout };
}
