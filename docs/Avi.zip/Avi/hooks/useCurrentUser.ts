import { useQueryClient } from "@tanstack/react-query";

type User = {
  id: number,
  email: string,
  pseudo: string
}

/**
 * Récupère les informtions de la session de l'utilisateur actuel (id, email, pseudo)
 * 
 * User : utilisateur connecté
 * Undefined : utilisateur non connecté
 * @returns 
 */
export function useCurrentUser(): User | undefined {
  const queryClient = useQueryClient();
  return queryClient.getQueryData<User>(["currentUser"]);
}

