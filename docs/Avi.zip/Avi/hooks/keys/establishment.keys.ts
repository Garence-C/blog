export const establishmentKeys = {
  all: ["establishments"] as const,
  detail: (id: number) => [...establishmentKeys.all, id] as const,
  openingInfos: (id: number) => ["openingInfos", id] as const,
};