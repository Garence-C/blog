export const opinionKeys = {
  all: ["opinions"] as const,
  byEstablishment: (establishmentId: number) =>
    [...opinionKeys.all, establishmentId] as const,
  opinion: (id: number) => ["opinion", id] as const,

};
