import { getEstablishmentById } from "@/constants/api/functions/establishment";
import { useQuery } from "@tanstack/react-query";
import { establishmentKeys } from "../keys/establishment.keys";

export function useEstablishment(establishmentId: number) {
  return useQuery({
    queryKey: establishmentKeys.detail(establishmentId),
    queryFn: () => getEstablishmentById(establishmentId),
    enabled: !!establishmentId,
    staleTime: 1000 * 60 * 5,
  });
}