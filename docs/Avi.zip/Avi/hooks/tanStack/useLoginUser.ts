import { loginApi } from "@/constants/api/auth";
import { UserLoginInput } from "@/constants/api/schemas/user.schema";
import { decodeToken } from "@/constants/authAppSide";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { router } from "expo-router";


export function useLoginUser() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: ({ email, password }: UserLoginInput) =>
            loginApi(email, password),
        onSuccess: (accessToken) => {
            const payload = decodeToken(accessToken);
            if (payload?.id) {
                queryClient.setQueryData(["currentUser"], {
                    id: payload.id,
                    email: payload.email,
                    pseudo: payload.pseudo,
                });
            }
            router.push("/tabs/searchHotelScreen");
        },
    });

}