import { getOpinion } from "@/constants/api/functions/opinion";
import { useQuery } from "@tanstack/react-query";
import { opinionKeys } from "../keys/opinion.keys";

export function useOpinion(opinionId: number) {
  return useQuery({
    queryKey: opinionKeys.opinion(opinionId),
    queryFn: () => getOpinion(opinionId),
    enabled: !!opinionId,
    staleTime: 1000 * 60 * 2,
  });
}
