import { getOpinionsByEstablishmentId } from "@/constants/api/functions/establishment";
import { useQuery } from "@tanstack/react-query";

export type OpinionFromApi = {
  id: number;
  createdAt: string;
  updatedAt: string;
  price: number;
  rating: number;
  commentary: string;
  userId: number;
};

export type OpinionsApiResponse = {
  countOpinions: number;
  opinions: OpinionFromApi[];
};

export function useOpinions(establishmentId: number) {
  return useQuery<OpinionsApiResponse>({
    queryKey: ["opinions", establishmentId],
    queryFn: () => getOpinionsByEstablishmentId(establishmentId),
    enabled: !!establishmentId,
    staleTime: 1000 * 60 * 2,
  });
}
