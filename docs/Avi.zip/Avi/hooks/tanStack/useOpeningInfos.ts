import { getEstablishmentById } from "@/constants/api/functions/establishment";
import { useQuery } from "@tanstack/react-query";

// Type pour les horaires d'ouverture
export type OpeningInfos = {
  infos?: {
    breakfast?: boolean;
    stageEvening?: boolean;
    midday?: boolean;
    evening?: boolean;
  };
};

export function useOpeningInfos(establishmentId: number) {
  return useQuery<OpeningInfos>({
    queryKey: ["openingInfos", establishmentId],
    queryFn: () => getEstablishmentById(establishmentId),
    enabled: !!establishmentId,
    staleTime: 1000 * 60 * 5,
  });
}