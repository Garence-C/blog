import { getEstablishments } from "@/constants/api/functions/establishment";
import { useQuery } from "@tanstack/react-query";
import { establishmentKeys } from "../keys/establishment.keys";

export function useEstablishments() {
    return useQuery({
    queryKey: establishmentKeys.all,
    queryFn: getEstablishments,
    staleTime: 1000 * 60 * 5, // 5 minutes
    })
}