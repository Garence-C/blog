import { updateOpinion } from "@/constants/api/functions/opinion";
import { OpinionUpdateInput } from "@/constants/api/schemas/opinion.schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { opinionKeys } from "../keys/opinion.keys";

type UpdateOpinionVariables = {
    id: string;
    data: OpinionUpdateInput;
};


export function useUpdateOpinion(establishmentId: number) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: ({ id, data }: UpdateOpinionVariables) =>
            updateOpinion(Number(id), data),

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: opinionKeys.byEstablishment(establishmentId),
            });

            queryClient.invalidateQueries({
                queryKey: ["establishments"],
            });
        }

    });
}
