import { OpinionCreateInput } from "@/constants/api/formSchema.schema";
import { createOpinion } from "@/constants/api/functions/establishment";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { opinionKeys } from "../keys/opinion.keys";


export function useCreateOpinion(establishmentId: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: OpinionCreateInput) =>
      createOpinion({establishmentId, data}),

    onSuccess: () => {
      // Liste des avis
      queryClient.invalidateQueries({
        queryKey: opinionKeys.byEstablishment(establishmentId),
      });

      // Met à jour les stats de la requête
      queryClient.invalidateQueries({
        queryKey: ["establishments"],
      });
    },
  });
}
