import { deleteOpinion } from "@/constants/api/functions/opinion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { opinionKeys } from "../keys/opinion.keys";

export function useDeleteOpinion(establishmentId: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteOpinion,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: opinionKeys.byEstablishment(establishmentId),
      });

      queryClient.invalidateQueries({
        queryKey: ["establishments"],
      });
    },
  });
}