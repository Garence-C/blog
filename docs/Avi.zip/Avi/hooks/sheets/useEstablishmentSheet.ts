import { useEstablishment } from "../tanStack/useEstablishment";
import { useOpeningInfos } from "../tanStack/useOpeningInfos";
import { useOpinions } from "../tanStack/useOpinions";

// NON UTILISE
export function useEstablishmentSheet(establishmentId: number) {
  const establishmentQuery = useEstablishment(establishmentId);
  const openingInfosQuery = useOpeningInfos(establishmentId);
  const opinionsQuery = useOpinions(establishmentId);

  return {
    establishment: establishmentQuery.data,
    openingInfos: openingInfosQuery.data,
    opinions: opinionsQuery.data?.opinions ?? [],

    isLoading:
      establishmentQuery.isLoading ||
      openingInfosQuery.isLoading ||
      opinionsQuery.isLoading,

    error:
      establishmentQuery.error ||
      openingInfosQuery.error ||
      opinionsQuery.error,
  };
}
