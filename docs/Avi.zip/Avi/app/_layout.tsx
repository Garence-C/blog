import AppStatusBar from "@/components/primitive/StatusBar";
import { decodeToken } from "@/constants/authAppSide";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SecureStore from "expo-secure-store";
import { useEffect } from "react";

const queryClient = new QueryClient();

export default function RootLayout() {
  useEffect(() => {
    (async () => {
      const token = await SecureStore.getItemAsync("accessToken");
      if (!token) return;

      const payload = decodeToken(token);
      if (payload?.id) {
        queryClient.setQueryData(["currentUser"], {
          id: payload.id,
          email: payload.email,
          pseudo: payload.pseudo,
        });
      }
    })();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AppStatusBar />
      <Stack screenOptions={{ headerShown: false }} />
    </QueryClientProvider>
  );
}
