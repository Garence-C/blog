import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';

export default function Index() {
  const router = useRouter();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Attend un petit délai pour que le layout soit monté
    const timeout = setTimeout(() => {
      setIsReady(true);
      router.replace('/tabs/searchScreen'); // Redirection après le montage TODO : remettre sign-in
    }, 100); // 100ms suffit souvent

    return () => clearTimeout(timeout);
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </View>
  );
}

// fair un display : none / block d'un container qui fait la taille du clavier et qui s'ajoute lorsque