import { useLocalSearchParams } from "expo-router";
import { Text } from "react-native";


export default function EditEstablishment() {
  const { id } = useLocalSearchParams<{ id: string }>(); // paramètre, nom du fichier

  return (
    <Text>Page de modification de l'établissement {id}</Text>
  )
}