import * as ImagePicker from "expo-image-picker";
import { Trash2 } from "lucide-react-native";
import { useState } from "react";
import { Button, Image, ScrollView, StyleSheet, View } from "react-native";

const API_URL = process.env.EXPO_PUBLIC_API_URL;

export default function UploadPhotos() {
  const [selectedImages, setSelectedImages] = useState([]);

  const openGallery = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsMultipleSelection: true,
      mediaTypes: ["images"],
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImages(result.assets);
    }
  };

  const uploadImages = async () => {
    const formData = new FormData();

    selectedImages.forEach((img, index) => {
      formData.append("image", {
        uri: img.uri.startsWith("file://") ? img.uri : `file://${img.uri}`,
        name: img.fileName || `photo_${Date.now()}_${index}.jpg`,
        type: "image/jpg", // on peut ajuster selon les format des images
      });
    });

    formData.append("establishmentId", "15");

    console.log("FormData:", formData);

    try {
      const res = await fetch(`${API_URL}/photos/uploads`, {
        method: "POST",
        body: formData,
        // NE PAS définir manuellement 'Content-Type'
      });

      const responseJson = await res.json();
      console.log(responseJson);
      alert("Images envoyées avec succès !");
    } catch (err) {
      console.error("Erreur lors de l’envoi des images :", err);
      alert("Erreur lors de l'envoi.");
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Button title="Choisir des images" onPress={openGallery} />
      <ScrollView horizontal style={{ marginVertical: 10 }}>
        <ScrollView horizontal>
          {/* Affichage des images */}
          {selectedImages.map((img, index) => (
            <View key={index}>
              <Image
                key={index}
                source={{ uri: img.uri }}
                style={styles.imagePreview}
              />
              {/* Suppresion de l'image à envoyer */}
              <Trash2
                size={20}
                stroke={"black"} // Couleur de l'icône
                strokeWidth={1.5} // Épaisseur du trait
                style={styles.trash}
                onPress={() => {
                  setSelectedImages((prev) =>
                    prev.filter((_, i) => i !== index)
                  );
                }}
              />
            </View>
          ))}
        </ScrollView>
      </ScrollView>
      <Button title="Envoyer les images" onPress={uploadImages} />
      {/* <EstablishmentPhotos /> */}
    </View>
  );
}

const styles = StyleSheet.create({
  imagePreview: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
    zIndex: 1,
  },
  trash: {
    position: "absolute",
    bottom: 5,
    right: 15,
    zIndex: 2,
    backgroundColor: "white",
    opacity: 0.8,
    borderRadius: 5,
    padding: 5,
  },
  container: {
    padding: 20,
  },
  title: {
    fontSize: 18,
    marginBottom: 10,
  },
  image: {
    width: 150,
    height: 150,
    marginRight: 10,
    borderRadius: 10,
  },
});
