import CustomButton from "@/components/primitive/CustomButton";
import BottomSheetDecompo from "@/components/primitive/EditingBottomSheet";
import EstablishmentIdentity from "@/components/primitive/EstablishmentIdentity";
import EstablishmentTypeBadge from "@/components/primitive/EstablishmentTypeBadge";
import HeaderBar from "@/components/primitive/HeaderBar";
import HeaderBarContainer from "@/components/primitive/HeaderBarContainer";
import { Loader } from "@/components/primitive/Loader";
import Marginbottom from "@/components/primitive/MarginBottom";
import Note from "@/components/primitive/Note";
import OpinionButton from "@/components/primitive/OpinionButton";
import ShowPhotos from "@/components/primitive/ShowPhotos";
import ThemedText from "@/components/ThemedText";
import { EstablishmentByIdResponse } from "@/constants/api/functions/establishment";
import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import { getDiffTime, getRatingStatus } from "@/constants/Utilities";
import { useDeleteOpinion } from "@/hooks/tanStack/useDeleteOpinion";
import { useEstablishment } from "@/hooks/tanStack/useEstablishment";
import { OpeningInfos, useOpeningInfos } from "@/hooks/tanStack/useOpeningInfos";
import { OpinionFromApi, useOpinions } from "@/hooks/tanStack/useOpinions";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ConciergeBell, Croissant, Ellipsis, Euro, Utensils } from "lucide-react-native";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


// Récupération de l'établissement depuis la réponse API
type Establishment = EstablishmentsResponse["establishments"][number];


export default function EstablishmentSheet() {
  const { id } = useLocalSearchParams<{ id: string }>(); // paramètre, nom du fichier
  const establishmentId = Number(id);

  // hooks isolés
  const { data: establishmentData } = useEstablishment(establishmentId);
  const { data: openingInfos } = useOpeningInfos(establishmentId);
  const { data: opinionsData } = useOpinions(establishmentId);

  // Constantes
  const establishment = establishmentData?.establishment;
  const opinions = opinionsData?.opinions ?? [];

  if(!establishment) {
    return <Text>Chargement…</Text>;
  }

  const callPhone = async (phone: string) => {
    const url = `tel:${phone}`;

    const canOpen = await Linking.canOpenURL(url);

    if (!canOpen) {
      Alert.alert(
        "Erreur",
        "Impossible d’ouvrir l’application Téléphone."
      );
      return;
    }

    Linking.openURL(url);
  };


  const handleCall = () => {
    Alert.alert(
      "Appeler l'établissement ?",
      establishment.tel,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Appeler',
          style: 'destructive',
          onPress: () => {
            console.log("Appel de l'établissement en cours ...");
            callPhone(establishment.tel);
          },
        },
      ]
    );
  };

  const handleMail = () => {
    Alert.alert(
      "Envoyer un mail ?",
      establishment?.email,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Envoyer un mail',
          style: 'destructive',
          onPress: () => {
            console.log("Envoie de l'email en cours ...");
            Linking.openURL(`mailto:${establishment?.email}`)
          }
        }
      ]
    )
  }


  const handleNavigate = () => {
    Alert.alert(
      "S'y rendre ?",
      establishment?.address + ", " + establishment?.city + ", " + establishment?.postCode,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: "S'y rendre",
          style: 'destructive',
          onPress: () => {
            console.log("Calcul de l'itiniraire en cours ...");
            Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(establishment?.address + ", " + establishment?.city + ", " + establishment?.postCode)}`);
          }
        }
      ]
    )
  }

  if (!establishment) {
    return <Loader />
  }
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>

        <HeaderBarContainer>
          <HeaderBar menuIsActive establishment={establishmentData} onCallEstablishment={handleCall} onSendMail={handleMail} onGoThere={handleNavigate} />
        </HeaderBarContainer>

        <View style={styles.content}>
          <ShowPhotos />
          <EstablishmentTypeBadge typeId={establishment.typeId} />
          <EstablishmentIdentity establishment={establishment} />

          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <OpeningAndPriceInfos
              establishment={establishment}
              openingInfos={openingInfos}
            />
          </ScrollView>
        </View>

        <OpinionsSection
          establishment={establishment}
          opinions={opinions}
        />
        <Marginbottom />
      </ScrollView>
      <OpinionButton establishmentId={establishment.id} />
    </SafeAreaView>
  );
}


function OpeningAndPriceInfos({
  establishment,
  openingInfos,
}: {
  establishment: EstablishmentByIdResponse["establishment"];
  openingInfos?: OpeningInfos;
}) {
  if (!openingInfos?.infos) return null;
  const infos = openingInfos.infos;

  return (
    <View style={{ display: "flex", flexDirection: "row", gap: 7 }}>
      <CustomButton
        size="small"
        sizeText="form"
        type="secondary"
        title={`${establishment.averagePrice} €`}
        icon={<Euro size={14} color="#B9375E" />}
      />
      {establishment.typeId === 1 && (
        <>
          {infos.breakfast && (
            <CustomButton
              size="small"
              sizeText="form"
              type="secondary"
              title="Petit-déjeuner"
              icon={<Croissant size={14} color="#B9375E" />}
            />
          )}
          {infos.stageEvening && (
            <CustomButton
              size="small"
              sizeText="form"
              type="secondary"
              title="Soirée étape"
              icon={<ConciergeBell size={14} color="#B9375E" />}
            />
          )}
        </>
      )}
      {establishment.typeId === 2 && (
        <>
          {infos.midday && (
            <CustomButton
              size="small"
              sizeText="form"
              type="secondary"
              title="Formule midi"
              icon={<Utensils size={14} color="#B9375E" />}
            />
          )}
          {infos.evening && (
            <CustomButton
              size="small"
              sizeText="form"
              type="secondary"
              title="Service du soir"
              icon={<ConciergeBell size={14} color="#B9375E" />}
            />
          )}
        </>
      )}
    </View>
  );
}

function OpinionsSection({
  establishment,
  opinions,
}: {
  establishment: EstablishmentByIdResponse["establishment"];
  opinions: OpinionFromApi[];
}) {
  const currentUser = useCurrentUser(); // récupère les données de la session actuelle

  return (
    <View style={styles.container}>
      <View style={[styles.content, { borderBottomWidth: 0 }]}>
        <ThemedText variant="h2" style={{ fontWeight: "bold" }}>
          Opinions des voyageurs
        </ThemedText>

        <ThemedText variant="h1">{establishment.averageRating}/5</ThemedText>

        <ThemedText variant="regular">
          {getRatingStatus(establishment.averageRating, establishment.typeId)}
        </ThemedText>

        <Note
          notation={establishment.averageRating}
          totalOpinions={establishment.countOpinions}
          totalOpinionsStyle="underline"
        />

        <FlatList
          scrollEnabled={false}
          data={opinions}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <OpinionItem
              opinion={item}
              establishment={establishment}
              currentUser={currentUser}
            />
          )}
          ListEmptyComponent={
            <Text style={{ textAlign: "center", marginTop: 20 }}>
              Aucun avis trouvé
            </Text>
          }
        />
      </View>
    </View>
  );
}


function OpinionItem({
  opinion,
  establishment,
  currentUser,
}: { opinion: OpinionFromApi, establishment: Establishment, currentUser: any }) {
  const router = useRouter();

  const establishmentId = establishment.id;

  const deleteOpinion = useDeleteOpinion(establishmentId);

  const isOwner = currentUser?.id === opinion.userId; // affiche les boutons de modifications et de suppression uniquement si l'utilisateur actuel est le propriétaier des commentaires.

  const handleDelete = () => {
    Alert.alert(
      "Supprimer l'avis",
      'Cette action est définitive. Voulez-vous continuer ?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: () => {
            console.log('Avis supprimé');
            deleteOpinion.mutate(opinion.id)
          },
        },
      ]
    );
  };

  const [openReview, setOpenReview] = useState(false);


  const handleEditOpinion = () => {
    router.push({
      pathname: "/tabs/establishmentOpinion/edit/[id]",
      params: {
        id: opinion.id.toString(),
        rating: opinion.rating.toString(),
        commentary: opinion.commentary,
        price: opinion.price?.toString() ?? "",
        establishmentId: establishmentId.toString()
      },
    });
  };

  const handleCall = () => {
    Alert.alert(
      "Appeler l'établissements ?",
      establishment.tel,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Appeler',
          style: 'destructive',
          onPress: () => {
            console.log('Avis supprimé');
          },
        },
      ]
    );
  };

  return (
    <View style={{ marginTop: 15 }}>
      <View style={styles.opinionContainer}>
        <View style={styles.opinionProfile}>
          {/* Nom de l'utilisateur */}
          <ThemedText
            variant={"h2"}
            style={{
              fontWeight: "bold",
              textAlign: "center",
              margin: "auto",
            }}
          >
            TBA
          </ThemedText>
        </View>
        <View style={styles.opinionDetails}>
          <ThemedText variant="regular" style={{ marginBottom: 7 }}>
            {getDiffTime(opinion.createdAt)}
          </ThemedText>
          <Note notation={opinion.rating} />
        </View>

        {isOwner && (
          <Pressable style={{ marginLeft: "auto" }} onPress={() => setOpenReview(true)}>
            <Ellipsis strokeWidth={1} />
          </Pressable>
        )}
      </View>

      <ThemedText variant="regular">{opinion.commentary}</ThemedText>

      <BottomSheetDecompo
        visible={openReview}
        onClose={() => setOpenReview(false)}
        type='review'
        onEditReview={handleEditOpinion}
        onDeleteReview={handleDelete}
        onCallEstablishment={handleCall}
      />

    </View>
  );
}



/* ---------- Styles (conservés comme demandé) ---------- */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    backgroundColor: "#FFFFFF",
  },
  content: {
    marginTop: 15,
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#E4E4E4",
    paddingBottom: 25,
  },
  title: {
    fontSize: 18,
    marginBottom: 10,
  },
  photoContainer: {
    flexDirection: "row",
    marginBottom: 10,
  },
  mainImage: {
    width: 180,
    height: 160,
    marginRight: 10,
    backgroundColor: "#EEE",
  },
  rightColumn: {
    justifyContent: "space-between",
    gap: 5,
  },
  secondaryImage: {
    width: 120,
    height: 75,
    backgroundColor: "#EEE",
  },
  opinionContainer: {
    flexDirection: "row",
    marginTop: 5,
    marginBottom: 5,
  },
  opinionProfile: {
    width: 55,
    height: 55,
    marginRight: 20,
    borderRadius: 50,
    backgroundColor: "#D9D9D9",
  },
  opinionDetails: {
    textAlign: "left",
    flexDirection: "column",
    justifyContent: "center",
  },
});
