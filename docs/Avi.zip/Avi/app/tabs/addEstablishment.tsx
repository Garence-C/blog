import ButtonForm from "@/components/forms/button-form";
import CustomButton from "@/components/primitive/CustomButton";
import HeaderBar from "@/components/primitive/HeaderBar";
import HeaderBarContainer from "@/components/primitive/HeaderBarContainer";
import { Input } from "@/components/primitive/Input";
import MarginBottom from "@/components/primitive/MarginBottom";
import Rating from "@/components/primitive/Rating";
import ThemedText from "@/components/ThemedText";
import { createEstablishment } from "@/constants/api/functions/establishment";
import { FullEstablishmentCreateInput } from "@/constants/api/schemas/establishment.schema";
import { useMutation } from "@tanstack/react-query";
import * as Location from 'expo-location';
import { router } from "expo-router";
import { BedDouble, Camera, Check, MapPin, Utensils } from "lucide-react-native";
import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, TextStyle, View, ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function Add() {
  const [name, setName] = useState('')
  const [city, setCity] = useState('')
  const [postCode, setPostCode] = useState('')
  const [longitude, setLongitude] = useState<number>()
  const [latitude, setLatitude] = useState<number>()
  const [address, setAddress] = useState('')
  const [tel, setTel] = useState('')
  const [email, setEmail] = useState('')
  const [typeId, setTypeId] = useState(0)

  // Hotel states
  const [stageEvening, setStageEvening] = useState<boolean>(false)
  const [breakfast, setBreakfast] = useState<boolean>(false)

  // Restaurant states
  const [midday, setMidday] = useState<boolean>(false);
  const [evening, setEvening] = useState<boolean>(false);


  // Opinion states
  const [price, setPrice] = useState('')
  const [rating, setRating] = useState<number | null>(null);
  const [commentary, setCommentary] = useState("");

  const mutation = useMutation({
    mutationFn: createEstablishment,
    onSuccess: (data) => {
      console.log("Etablissement créé : ", data);
    },
    onError: (error) => {
      console.error("Erreur : ", error);
    },
  });

  const [error, setError] = useState('');


  const handleGeocode = async () => {
    try {
      // Vérifier input
      if (!address.trim()) {
        setError('Veuillez entrer une adresse');
        return;
      }

      // Demande permission
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setError('Permission de localisation refusée');
        return;
      }

      // Géocodage
      const locations = await Location.geocodeAsync(`${city}, ${address}, ${postCode}`);
      console.log("locations :", locations)

      if (locations.length === 0) {
        setError('Adresse introuvable');
        return null;
      }

      // Succès
      const { latitude, longitude } = locations[0];
      setLatitude(latitude);
      setLongitude(longitude);
      console.log("latitude :", latitude)
      console.log("longitude :", longitude)

      return { latitude, longitude };
    } catch (e) {
      setError(e.message);
      return null;
    }
  };

  const getUserLocation = async () => {
    try {
      // Demande de permission
      const { status } = await Location.requestForegroundPermissionsAsync()
      if (status !== 'granted') {
        console.log('Permission refusée')
        return
      }

      // Récupération de la position
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      })

      console.log('Latitude:', location.coords.latitude)
      console.log('Longitude:', location.coords.longitude)

      setLatitude(location.coords.latitude)
      setLongitude(location.coords.longitude)

      // Reverse Geocoding pour récupérer la ville et code postal
      const addressData = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      if (addressData.length > 0) {
        const data = addressData[0];
        setCity(data.city || '');
        setPostCode(data.postalCode || '');

        const fullAddress = [data.name, data.street]
          .filter(Boolean)
          .join(', ');
        setAddress(fullAddress);
      }

    } catch (error) {
      console.log('Erreur GPS:', error)
    }
  }

  function handleSubmit(coords) {
    const basePayload = {
      establishment: {
        name,
        city,
        postCode,
        tel,
        address,
        longitude: coords.longitude.toString(),
        latitude: coords.latitude.toString(),
        email,
        typeId,
      },
      opinion: {
        price: Number(price) || 18,
        rating: rating ?? 3,
        commentary,
      },
    };

    let payload: FullEstablishmentCreateInput;
    if (typeId === 1 && (!breakfast && !stageEvening)) {
      alert("Veuillez renseigner les infos hôtel");
      return;
    }

    if (typeId === 2 && !midday && !evening) {
      alert("Veuillez renseigner les horaires du restaurant");
      return;
    }

    if (typeId === 1) {
      // HOTEL
      payload = {
        ...basePayload,
        hotelInfos: {
          breakfast,
          stageEvening,
        },
      };
    } else if (typeId === 2) {
      // RESTAURANT
      payload = {
        ...basePayload,
        restaurantInfos: {
          midday,
          evening,
        },
      };
    } else {
      console.error("Type d'établissement invalide");
      return;
    }



    mutation.mutate(payload);
    router.push('/tabs/searchHotelScreen')
  }


  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <HeaderBarContainer>
          <HeaderBar />
        </HeaderBarContainer>
        <View style={styles.content}>

          <ThemedText variant={'form'} color="black" style={styles.label}>
            Nom de l'étalissement
          </ThemedText>
          <Input placeholder="Nom de l'établissement" placeholderTextColor={"#B9375E"} value={name} onChangeText={setName} style={styles.input} />
          <ThemedText variant={'form'} color="black" style={styles.label} >
            Ville
          </ThemedText>
          <Input placeholder="Ville" placeholderTextColor={"#B9375E"} value={city} onChangeText={setCity} style={styles.input} />
          <ThemedText variant={'form'} color="black" style={styles.label} >
            Code postal
          </ThemedText>
          <Input placeholder="Code postal" placeholderTextColor={"#B9375E"} value={postCode} onChangeText={setPostCode} style={styles.input} />
          <ThemedText variant={'form'} color="black" style={styles.label} >
            Adresse
          </ThemedText>
          <View style={{ flexDirection: 'row', gap: 4 }}>
            <Input placeholder="Adresse" placeholderTextColor={"#B9375E"} value={address} onChangeText={setAddress} style={styles.inputWith2} />
            <Pressable
              style={{
                backgroundColor: '#FFE0E9',
                borderRadius: 8,
                alignItems: 'center',
                padding: 12,
                height: 44,
                paddingTop: 12,
                width: '12%'
              }}
              onPressIn={getUserLocation}
            >
              <MapPin color={'#B9375E'} size={16} />
            </Pressable>

          </View>
          <ThemedText variant={'form'} color="black" style={styles.label} >
            N° de téléphone
          </ThemedText>
          <Input placeholder="02.02.02.02.02" placeholderTextColor={"#B9375E"} value={tel} onChangeText={setTel} style={styles.input} />
          <ThemedText variant={'form'} color="black" style={styles.label} >
            E-mail
          </ThemedText>
          <Input placeholder="contact@hotel.fr" placeholderTextColor={"#B9375E"} value={email} onChangeText={setEmail} style={styles.input} />


          <ThemedText variant={'form'} color="black" style={styles.label} >
            Quel type d'établissement s'agit-il ?
          </ThemedText>
          <View style={styles.contentButton}>
            <CustomButton
              onPress={() => {
                setTypeId(1)
              }}
              type={typeId === 1 ? "primary" : "secondary"}
              size="form"
              sizeText="form"
              title={"Hôtel"}
              icon={<BedDouble size={16} color="#B9375E" />}
            />
            <CustomButton
              onPress={() => {
                setTypeId(2)
              }}
              type={typeId === 2 ? "primary" : "secondary"}
              title={"Restaurant"}
              size="form"
              sizeText="form"
              icon={<Utensils size={16} color="#B9375E"
              />}
            />
          </View>
        </View>
        
        {/*----------- Hotel ----------- */}
        {typeId === 1 && (
          <View style={styles.contentButtonForm}>
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Cet hôtel propose-t-il des soirées étapes ?
            </ThemedText>
            <ButtonForm
              options={["Oui", "Non"]}
              defaultValue="Non"
              onSelect={(value) => {
                setStageEvening(value === "Oui");
              }}
            />
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Cet hôtel propose-t-il le petit déjeuner ?
            </ThemedText>
            <ButtonForm
              options={["Oui", "Non"]}
              defaultValue="Non"
              onSelect={(value) => {
                setBreakfast(value === "Oui");
              }}
            />
          </View>
        )}

        {/*----------- Restaurant ----------- */}
        {typeId === 2 && (
          <View style={styles.contentButtonForm}>
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Le restaurant est-il ouvert le midi, le soir ou les deux ?
            </ThemedText>
            <ButtonForm
              options={["Midi", "Soir", "Les deux"]}
              defaultValue="Midi"
              onSelect={(value) => {
                if (value === "Les deux") {
                  setMidday(true);
                  setEvening(true);
                  return;
                }

                const isYes = value === "Midi";
                setMidday(isYes);
                setEvening(isYes);
              }}
            />

          </View>
        )}

        {/*----------- Opinion ----------- */}
        {typeId !== 0 && (
          <View style={styles.content}>
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Quel a été {typeId === 1 ? "le prix pour une nuit ?" : "le montant de l'addition ?"}
            </ThemedText>
            <Input placeholder="20.00€" placeholderTextColor={"#B9375E"} value={price} onChangeText={setPrice} style={styles.inputPrice} />
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Quelle note donneriez-vous à votre expérience ?
            </ThemedText>
            <Rating value={rating} onChange={setRating} />
            <ThemedText variant={'form'} color="black" style={styles.label} >
              Écrivez quelques lignes pour raconter votre expérience ?
            </ThemedText>
            <Input
              placeholder=""
              placeholderTextColor={"#B9375E"}
              value={commentary}
              onChangeText={setCommentary}
              style={styles.exp}
              multiline={true}
              numberOfLines={6}
              textAlignVertical="top"
            />
            <View style={styles.contentButton}>
              <CustomButton
                title={"Ajouter des photos"}
                type="primary"
                size="small"
                sizeText='avis'
                onPress={() => {
                  router.push('/tabs/searchHotelScreen')
                }}
                icon={<Camera size={16} color="#B9375E" />}
              />
            </View>
            <View style={styles.contentConfirm} >
              <CustomButton
                title={"Ajouter un établissement"}
                type="primary"
                size="small"
                sizeText='avis'
                onPress={async () => {
                  const coords = await handleGeocode();
                  if (!coords) return;
                  handleSubmit(coords);
                }}
                icon={<Check size={16} color="#B9375E" />}
              />
            </View>
          </View>
        )}
        <MarginBottom />
      </ScrollView>
    </SafeAreaView>

  );
}

const styles = StyleSheet.create<{
  // Enlève les erreurs de type en définissant explicitement les types
  container: ViewStyle,
  label: TextStyle,
  content: ViewStyle,
  contentButton: ViewStyle,
  contentButtonForm: ViewStyle,
  contentConfirm: ViewStyle,
  input: TextStyle,
  inputWith2: TextStyle,
  inputPrice: TextStyle,
  exp: TextStyle
}>({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    backgroundColor: "#FFFFFF",
    paddingTop: 20
  },
  label: {
    marginBottom: 2,
    marginTop: 10,
    fontWeight: 'bold',
  },
  content: {
    marginTop: 15,
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#E4E4E4',
    paddingBottom: 25
  },
  contentButton: {
    marginTop: 15,
    marginBottom: 4,
    flexDirection: 'row'
  },
  contentButtonForm: {
    marginTop: 14,
    marginBottom: 12,
    marginLeft: 25,
    gap: 10
  },
  contentConfirm: {
    justifyContent: 'center',
    marginTop: 24,
    marginHorizontal: "auto"
  },
  input: {
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#B9375E',
    fontSize: 13,
    paddingHorizontal: 10,
  },
  inputWith2: {
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#B9375E',
    fontSize: 13,
    paddingHorizontal: 10,
    width: '88%',
  },
  inputPrice: {
    marginBottom: 12,
    width: 65,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#B9375E',
    fontSize: 13,
    paddingHorizontal: 10
  },
  exp: {
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#B9375E',
    fontSize: 13,
    paddingHorizontal: 10,
    height: 100,
  }
})