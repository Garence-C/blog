import SearchHotel from "@/components/primitive/SearchHotel";
import { useEstablishments } from "@/hooks/tanStack/useEstablishments";
import React from "react";
import { StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";



export default function SearchHotelScreen() {
  // Données d'établissements récupérées
  const { data: allEstablishments } = useEstablishments();
  const establishments = allEstablishments?.establishments ?? [];

  return (
    <SafeAreaView style={styles.container}>
      <SearchHotel establishments={establishments} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 16,
  },
});
