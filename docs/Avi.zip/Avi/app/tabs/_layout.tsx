import * as NavigationBar from "expo-navigation-bar";
import { Tabs } from "expo-router";
import { MapPinned, Plus, Search } from "lucide-react-native";
import React, { useEffect } from "react";
import { AppState, Text, TouchableWithoutFeedback, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";

export default function TabsLayout() {

useEffect(() => {
    let timeout: NodeJS.Timeout | null = null;

    const hideNavBar = async () => {
      await NavigationBar.setBehaviorAsync("overlay-swipe");
      await NavigationBar.setVisibilityAsync("hidden");
    };

    hideNavBar();

    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") {
        // délais pour laisser à Android le stemps de faire sa transition
        timeout = setTimeout(() => {
          hideNavBar();
        }, 300);
      }
    });

    return () => {
      subscription.remove();
      if (timeout) clearTimeout(timeout);
    };
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#B9375E',
          tabBarInactiveTintColor: '#656565',
          tabBarHideOnKeyboard: true,
          tabBarStyle: {
            backgroundColor: '#F3F3F3',
            height: 80,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            position: 'absolute',
            bottom: 0,
            borderTopWidth: 0
          },
          tabBarLabelStyle: {
            fontFamily: "RobotoCondensed-Regular",
            fontSize: 12,
            fontWeight: "600"
          }
        }}
      >

        <Tabs.Screen
          name="searchHotelScreen"
          options={{
            tabBarIcon: ({ color, size, focused }) => (
              <View style={{ alignItems: "center" }}>
                {focused && (
                  <View
                    style={{
                      position: "absolute",
                      top: -7,
                      width: 58,
                      height: 2.5,
                      backgroundColor: "#B9375E",
                      marginBottom: 6,
                    }}
                  />
                )}

                <Search size={size} color={color} strokeWidth={1.5} />
              </View>
            ),

            tabBarLabel: ({ focused, color }) => (
              <Text
                style={{
                  color,
                  fontSize: 12,
                  fontWeight: focused ? "bold" : "500",
                }}
              >
                Rechercher
              </Text>
            ),
          }}
        />

        <Tabs.Screen
          name="addEstablishment"
          options={{
            tabBarLabel: () => null,
            tabBarButton: (props) => (
              <View
                style={{
                  flex: 1,
                  alignItems: "center",
                }}
              >
                <TouchableWithoutFeedback onPress={props.onPress}>
                  <View
                    style={{
                      width: 95,
                      height: 95,
                      borderRadius: 100,
                      backgroundColor: "#FFFFFF",
                      justifyContent: "center",
                      alignItems: "center",
                      marginTop: -42,
                    }}
                  >
                    <View
                      style={{
                        width: 70,
                        height: 70,
                        borderRadius: 35,
                        backgroundColor: "#B9375E",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Plus size={46} color="#FFFFFF" strokeWidth={1} />
                    </View>
                  </View>
                </TouchableWithoutFeedback>
              </View>
            ),
          }}
        />

        <Tabs.Screen
          name="map"
          options={{
            tabBarIcon: ({ color, size, focused }) => (
              <View style={{ alignItems: "center" }}>
                {focused && (
                  <View
                    style={{
                      position: "absolute",
                      top: -7,
                      width: 58,
                      height: 2.5,
                      backgroundColor: "#B9375E",
                      marginBottom: 6,
                    }}
                  />
                )}

                <MapPinned size={size} color={color} strokeWidth={1.5} />
              </View>
            ),

            tabBarLabel: ({ focused, color }) => (
              <Text
                style={{
                  color,
                  fontSize: 12,
                  fontWeight: focused ? "bold" : "500",
                }}
              >
                Carte
              </Text>
            ),
          }}
        />

        <Tabs.Screen
          name="searchScreen"
          options={{
            href: null, // pour déactiver l'icon dans la tab bar
          }}
        />

        <Tabs.Screen
          name="resultSearchScreen"
          options={{
            href: null, // pour déactiver l'icon dans la tab bar
          }}
        />

        <Tabs.Screen
          name="establishmentOpinion/create/[id]"
          options={{
            href: null, // pour déactiver l'icon dans la tab bar
          }}
        />

        <Tabs.Screen
          name="establishmentOpinion/edit/[id]"
          options={{
            href: null, // pour déactiver l'icon dans la tab bar
          }}
        />

        <Tabs.Screen
          name="establishmentSheet/[id]"
          options={{
            href: null, // pour déactiver l'icon dans la tab bar
          }}
        />

      </Tabs>
    </GestureHandlerRootView>
  );
}