import CustomHandle from '@/components/primitive/CustomHandle';
import FilterScroll from '@/components/primitive/FilterScroll';
import PlaceCard, { Place } from '@/components/primitive/PlaceCard';
import BottomSheet, { BottomSheetFlatList } from '@gorhom/bottom-sheet';
import React, { useMemo, useRef, useState } from "react";
import {
  Image,
  StyleSheet,
  View
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import { places } from "../../assets/data/places"; // tes données locales


export default function MapScreen() {

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const mapRef = useRef<any>(null);
  const flatListRef = useRef<any>(null);

  const filteredPlaces = (() => {
    let filtered = places.filter(place => selectedTypes.length === 0 || selectedTypes.includes(place.type));
    if (selectedFilters.includes('breakfastIncluded')) {
      filtered = filtered.filter(p => p.breakfastIncluded);
    }
    if (selectedFilters.includes('stageEvening')) {
      filtered = filtered.filter(p => p.stageEvening);
    }
    if (selectedFilters.includes('bestRated')) {
      filtered = [...filtered].sort((a, b) => b.rating - a.rating);
    }
    if (selectedFilters.includes('mostRecent')) {
      filtered = [...filtered].sort((a, b) => new Date(b.dateAdded || '2020-01-01').getTime() - new Date(a.dateAdded || '2020-01-01').getTime());
    }

    console.log('SelectedTypes:', selectedTypes);
    console.log('SelectedFilters:', selectedFilters);
    console.log('FilteredPlaces count:', filtered.length);
    return filtered;
  })();

  // Fonction pour centrer le marker et scroller la liste
  const focusOnPlace = (place: Place) => {

    // Centre la carte
    mapRef.current?.animateToRegion({
      latitude: place.latitude,
      longitude: place.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
      350 // durée animation en ms
    );

    // Scroll liste
    const filteredIndex = filteredPlaces.findIndex(
      p => p.id === place.id
    );
    if (filteredIndex !== -1) {
      flatListRef.current?.scrollToIndex({
        index: filteredIndex,
        animated: true,
        viewOffset: 50,
      });
    }

    setSelectedId(place.id);

  };

  const getMarkerImage = (type: string, isSelected: boolean) => {
    if (type === "hotel") {
      return isSelected
        ? require("../../assets/images/hotelMarkerSelected.png")
        : require("../../assets/images/hotelMarker.png");
    }

    // restaurant par défaut
    return isSelected
      ? require("../../assets/images/restoMarkerSelected.png")
      : require("../../assets/images/restoMarker.png");
  };

  const mapStyle = [
    {
      featureType: "poi",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "transit",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "road",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
  ];

  const BOTTOM_SHEET_HEIGHT = 350

  // variables
  const snapPoints = useMemo(() => [BOTTOM_SHEET_HEIGHT * 0.45, BOTTOM_SHEET_HEIGHT * 1], []);

  const ITEM_HEIGHT = 740;
  const padB = 270 * places.length
  const paddingBottom =
    Math.min(
      ITEM_HEIGHT * 2,
      ITEM_HEIGHT * filteredPlaces.length
    );

  const filtersConfig = [
    {
      id: "hotel",
      label: "Hôtels",
      selected: selectedTypes.includes("hotel"),
      onToggle: () => {
        setSelectedTypes((prev) =>
          prev.includes("hotel")
            ? prev.filter((t) => t !== "hotel")
            : [...prev, "hotel"]
        );
      },
    },
    {
      id: "restaurant",
      label: "Restaurant",
      selected: selectedTypes.includes("restaurant"),
      onToggle: () => {
        setSelectedTypes((prev) =>
          prev.includes("restaurant")
            ? prev.filter((t) => t !== "restaurant")
            : [...prev, "restaurant"]
        );
      },
    },
    {
      id: "bestRated",
      label: "Le mieux noté",
      selected: selectedFilters.includes("bestRated"),
      onToggle: () => {
        setSelectedFilters((prev) =>
          prev.includes("bestRated")
            ? prev.filter((f) => f !== "bestRated")
            : [...prev, "bestRated"]
        );
      },
    },
    {
      id: "breakfastIncluded",
      label: "Petit déjeuner inclus",
      selected: selectedFilters.includes("breakfastIncluded"),
      onToggle: () => {
        setSelectedFilters((prev) =>
          prev.includes("breakfastIncluded")
            ? prev.filter((f) => f !== "breakfastIncluded")
            : [...prev, "breakfastIncluded"]
        );
      },
    },
    {
      id: "stageEvening",
      label: "Soirée étape",
      selected: selectedFilters.includes("stageEvening"),
      onToggle: () => {
        setSelectedFilters((prev) =>
          prev.includes("stageEvening")
            ? prev.filter((f) => f !== "stageEvening")
            : [...prev, "stageEvening"]
        );
      },
    },
    {
      id: "mostRecent",
      label: "Le plus récent",
      selected: selectedFilters.includes("mostRecent"),
      onToggle: () => {
        setSelectedFilters((prev) =>
          prev.includes("mostRecent")
            ? prev.filter((f) => f !== "mostRecent")
            : [...prev, "mostRecent"]
        );
      },
    },
  ];

  return (
    <View style={styles.container}>
      {/* MAP */}
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={{
          latitude: 47.70614,
          longitude: -1.361903,
          latitudeDelta: 0.08,
          longitudeDelta: 0.08,
        }}
        onPress={() => {
          setSelectedId(null);
          flatListRef.current?.scrollToOffset({
            offset: 0,
            animated: true,
          });
        }}
        showsPointsOfInterest={false}
        showsBuildings={false}
        showsIndoors={false}
        customMapStyle={mapStyle}
      >

        {filteredPlaces.map((place) => {

          const isSelected = selectedId === place.id;

          return (
            <Marker
              key={place.id}
              coordinate={{
                latitude: place.latitude,
                longitude: place.longitude,
              }}
              onPress={() => {
                setSelectedId(place.id);
                focusOnPlace(place);
              }}
            >
              <Image
                source={getMarkerImage(place.type, isSelected)}
                style={{ width: 40, height: 36 }}
                resizeMode="contain"
              />
            </Marker>
          );
        })}
      </MapView>

      <View style={styles.bottomSheetContainer}>
        <BottomSheet
          index={0}
          snapPoints={snapPoints}
          handleComponent={CustomHandle}
          enableOverDrag={false}
          enablePanDownToClose={false}
          detached={true}
          backgroundStyle={{ backgroundColor: 'white', borderTopLeftRadius: 20, borderTopRightRadius: 20 }}
        >

          <View style={styles.listContainer}>
            <BottomSheetFlatList
              ref={flatListRef}
              data={filteredPlaces}
              keyExtractor={(item) => item.id.toString()}
              stickyHeaderIndices={[0]}
              style={styles.list}
              showsVerticalScrollIndicator={true}
              contentContainerStyle={{ paddingBottom: padB }}
              ListHeaderComponent={
                <View style={styles.stickyHeader}>

                  <FilterScroll filters={filtersConfig} styles={styles} variant={"map"}/>

                  {/*
                  
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.filtersScroll}
                  >

                    <TouchableOpacity
                      onPress={() => {
                        if (selectedTypes.includes('hotel')) {
                          setSelectedTypes(selectedTypes.filter(t => t !== 'hotel'));
                        } else {
                          setSelectedTypes([...selectedTypes, 'hotel']);
                        }
                      }}
                      style={[styles.filterButton, selectedTypes.includes('hotel') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedTypes.includes('hotel') && styles.filterButtonTextSelected]}>Hôtel</Text>
                      {selectedTypes.includes('hotel') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (selectedTypes.includes('restaurant')) {
                          setSelectedTypes(selectedTypes.filter(t => t !== 'restaurant'));
                        } else {
                          setSelectedTypes([...selectedTypes, 'restaurant']);
                        }
                      }}
                      style={[styles.filterButton, selectedTypes.includes('restaurant') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedTypes.includes('restaurant') && styles.filterButtonTextSelected]}>Restaurant</Text>
                      {selectedTypes.includes('restaurant') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (selectedFilters.includes('bestRated')) {
                          setSelectedFilters(selectedFilters.filter(f => f !== 'bestRated'));
                        } else {
                          setSelectedFilters([...selectedFilters, 'bestRated']);
                        }
                      }}
                      style={[styles.filterButton, selectedFilters.includes('bestRated') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedFilters.includes('bestRated') && styles.filterButtonTextSelected]}>Le mieux noté</Text>
                      {selectedFilters.includes('bestRated') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (selectedFilters.includes('breakfastIncluded')) {
                          setSelectedFilters(selectedFilters.filter(f => f !== 'breakfastIncluded'));
                        } else {
                          setSelectedFilters([...selectedFilters, 'breakfastIncluded']);
                        }
                      }}
                      style={[styles.filterButton, selectedFilters.includes('breakfastIncluded') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedFilters.includes('breakfastIncluded') && styles.filterButtonTextSelected]}>Petit déjeuner inclus</Text>
                      {selectedFilters.includes('breakfastIncluded') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (selectedFilters.includes('stageEvening')) {
                          setSelectedFilters(selectedFilters.filter(f => f !== 'stageEvening'));
                        } else {
                          setSelectedFilters([...selectedFilters, 'stageEvening']);
                        }
                      }}
                      style={[styles.filterButton, selectedFilters.includes('stageEvening') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedFilters.includes('stageEvening') && styles.filterButtonTextSelected]}>Soirée étape</Text>
                      {selectedFilters.includes('stageEvening') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (selectedFilters.includes('mostRecent')) {
                          setSelectedFilters(selectedFilters.filter(f => f !== 'mostRecent'));
                        } else {
                          setSelectedFilters([...selectedFilters, 'mostRecent']);
                        }
                      }}
                      style={[styles.filterButton, selectedFilters.includes('mostRecent') && styles.filterButtonSelected]}
                    >
                      <Text style={[styles.filterButtonText, selectedFilters.includes('mostRecent') && styles.filterButtonTextSelected]}>Le plus récent</Text>
                      {selectedFilters.includes('mostRecent') && <X size={12} color="#B9375E" />}
                    </TouchableOpacity>

                  </ScrollView>
                  
                */}
                </View>
              }

              renderItem={({ item }) => {
                return (
                  <PlaceCard
                    place={item}
                    onPress={() => focusOnPlace(item)}
                    onReviewPress={() => alert(`Écrire un avis pour ${item.name}`)}
                  />
                );
              }}
            />
          </View>
        </BottomSheet>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 2,
  },
  mapCollapsed: {
    flex: 3,
  },
  collapsibleContainer: {
    flex: 1.25,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
  },
  arrowButton: {
    alignSelf: 'center',
    padding: 0,
    borderRadius: 20,
  },
  arrowButtonCollapsed: {
    position: 'absolute',
    bottom: 125,
    alignSelf: 'center',
    padding: 10,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
  },
  filterContainer: {
    flex: 0.01,
  },
  listContainer: {
    flex: 1.2,
  },
  filtersScroll: {
    padding: 10,
    paddingTop: 4,
    paddingBottom: 4,
    backgroundColor: '#FFFFFF',
  },
  filterButton: {
    paddingTop: 6,
    paddingBottom: 3,
    paddingLeft: 12,
    paddingRight: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    borderWidth: 1.25,
    borderColor: '#B9375E',
    marginRight: 10,
    paddingVertical: 6,
    height: 32,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  filterButtonSelected: {
    backgroundColor: '#FFE0E9',
    borderColor: '#FFE0E9',
  },
  filterButtonText: {
    color: '#B9375E',
    fontSize: 14,
    lineHeight: 18,
    fontWeight: 'bold',
  },
  filterButtonTextSelected: {
    backgroundColor: '#FFE0E9',
  },
  list: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 10,
  },
  title: {
    fontWeight: "bold",
    marginBottom: 4,
  },
  type: {
    color: "#888",
    fontSize: 12,
  },
  bottomSheetContainer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: 350,
  },
  stickyHeader: {
    backgroundColor: '#FFFFFF',
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    marginTop: -14,
    marginBottom: 2,
  },
});
