import { OpinionForm } from "@/components/forms/OpinionForm";
import EstablishmentIdentity from "@/components/primitive/EstablishmentIdentity";
import EstablishmentTypeBadge from "@/components/primitive/EstablishmentTypeBadge";
import HeaderBar from "@/components/primitive/HeaderBar";
import HeaderBarContainer from "@/components/primitive/HeaderBarContainer";
import { Loader } from "@/components/primitive/Loader";
import Marginbottom from "@/components/primitive/MarginBottom";
import ShowPhotos from "@/components/primitive/ShowPhotos";
import SubmitButton from "@/components/primitive/SubmitButton";
import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import { useOpinionForm } from "@/hooks/forms/useOpinionForm";
import { useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


export default function CreateOpinionScreen() {
  const { id } = useLocalSearchParams<{
    id: string; // ID de l'établissement
  }>();

  const router = useRouter();
  const queryClient = useQueryClient();
  const establishmentId = Number(id);

  const establishment = useMemo(() => {
    const data = queryClient.getQueryData<EstablishmentsResponse>(["establishments"]);
    return data?.establishments.find(e => e.id === establishmentId);
  }, [queryClient, establishmentId]);

  if (!establishment) {
    return <Loader />
  }

  const {
    form,
    submit,
    submitLabel,
    isLoading
  } = useOpinionForm({
    mode: "create",
    establishmentId,
    onSuccess: () =>
      router.push({
        pathname: "/tabs/establishmentSheet/[id]",
        params: { id: establishmentId.toString() },
      })
  })

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'android' ? 'padding' : undefined}
      >
        <ScrollView>
          <HeaderBarContainer>
            <HeaderBar />
          </HeaderBarContainer>
          <View style={styles.content}>
            <ShowPhotos />
            <EstablishmentTypeBadge typeId={establishment.typeId} />
            <EstablishmentIdentity establishment={establishment} />
          </View>
          <OpinionForm
            form={form}
            variant="create"
          />
          <SubmitButton
            submitLabel={submitLabel}
            isLoading={isLoading}
            onPress={submit}
          />
          <Marginbottom />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    backgroundColor: "#fff"
  },
  content: {
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    marginTop: 14,
    gap: 10,
    paddingBottom: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#E4E4E4',
  },

});
