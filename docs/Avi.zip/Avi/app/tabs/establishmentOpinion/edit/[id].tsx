import { OpinionForm } from "@/components/forms/OpinionForm";
import EstablishmentIdentity from "@/components/primitive/EstablishmentIdentity";
import EstablishmentTypeBadge from "@/components/primitive/EstablishmentTypeBadge";
import HeaderBar from "@/components/primitive/HeaderBar";
import HeaderBarContainer from "@/components/primitive/HeaderBarContainer";
import Marginbottom from "@/components/primitive/MarginBottom";
import ShowPhotos from "@/components/primitive/ShowPhotos";
import SubmitButton from "@/components/primitive/SubmitButton";
import { EstablishmentsResponse } from "@/constants/api/schemas/establishment.schema";
import { useOpinionForm } from "@/hooks/forms/useOpinionForm";
import { useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function EditOpinionScreen() {
  const { id, price, rating, commentary, establishmentId } = useLocalSearchParams<{
    id: string;
    price: string;
    rating: string;
    commentary: string;
    establishmentId: string;
  }>();

  // hooks
  const router = useRouter();
  const queryClient = useQueryClient();
  const intEstablishmentId = Number(establishmentId);

  const establishment = useMemo(() => {
    const data = queryClient.getQueryData<EstablishmentsResponse>(["establishments"]);
    return data?.establishments.find(e => e.id === intEstablishmentId);
  }, [queryClient, establishmentId]);

  if (!establishment) {
    return <Text>Chargement…</Text>;
  }

  const opinion = {
    id,
    price,
    rating: rating ? Number(rating) : null,
    commentary,
  }

  const {
    form,
    submit,
    submitLabel,
    isLoading
  } = useOpinionForm({
    mode: "edit",
    establishmentId: Number(establishmentId),
    opinion,
    onSuccess: () =>
      router.push({
        pathname: "/tabs/establishmentSheet/[id]",
        params: { id: establishmentId.toString() },
      })

  })


  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'android' ? 'padding' : undefined}
      >
        <ScrollView>
          <HeaderBarContainer>
            <HeaderBar />
          </HeaderBarContainer>
          <View style={styles.content}>
            <ShowPhotos />
            <EstablishmentTypeBadge typeId={establishment.typeId} />
            <EstablishmentIdentity establishment={establishment} />
          </View>
          <OpinionForm
            form={form}
            variant="edit"
          />
          <SubmitButton
            submitLabel={submitLabel}
            isLoading={isLoading}
            onPress={submit}
          />
          <Marginbottom />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "flex-start", backgroundColor: "#FFFFFF" },
  endContent: {
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    paddingBottom: 25,
  },
  label: {
    marginBottom: 2,
    marginTop: 10,
    fontWeight: "bold"
  },
  contentConfirm: {
    justifyContent: "center",
    marginTop: 24,
    marginInline: "auto"
  },
  content: {
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    paddingBottom: 25,
    borderBottomColor: "#E4E4E4",
    borderBottomWidth: 1
  },
  inputPrice: {
    marginBottom: 12,
    width: 65,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#B9375E",
    fontSize: 13,
    paddingHorizontal: 10,
  },
  exp: {
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#B9375E",
    fontSize: 13,
    paddingHorizontal: 10,
    height: 100,
  },
  error: { color: "#B9375E", fontWeight: "600", marginTop: 6 },
});
