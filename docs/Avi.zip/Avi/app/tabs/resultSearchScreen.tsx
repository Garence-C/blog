import HeaderBar from "@/components/primitive/HeaderBar";
import SearchHotel from "@/components/primitive/SearchHotel";
import { useSearchEstablishments } from "@/hooks/utils/useSearchEstablishments";
import { useLocalSearchParams } from "expo-router";
import React from "react";
import { StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function ResultSearchScreen() {
  const { query } = useLocalSearchParams<{ query?: string }>();

  const filteredEstablishments = useSearchEstablishments({ query });

  return (
      <SafeAreaView style={styles.container}>
        <HeaderBar title={query} />

        <SearchHotel establishments={filteredEstablishments} isResultResearch={true} />
      </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 16,
    marginBottom: 40
  },
  content: {
    marginTop: 15,
    marginRight: 25,
    marginLeft: 25,
    marginBottom: 14,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#E4E4E4",
    paddingBottom: 25,
  },
  backContainer: {
    marginBottom: 0,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 0,
  },
  title: {
    flex: 1,
    textAlign: "center",
    fontSize: 24,
    fontWeight: "bold",
    marginRight: 40, // Pour compenser le bouton "Back"
  },
  toggleContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 20,
  },
  toggleButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    backgroundColor: "#eee",
  },
  activeButton: {
    backgroundColor: "#ff5a5f",
  },
  activeText: {
    color: "#fff",
    fontWeight: "bold",
  },
  inactiveText: {
    color: "#333",
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f1f1f1",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginTop: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  filters: {
    marginTop: 16,
  },
  filterButton: {
    backgroundColor: "#eee",
    paddingVertical: 4,
    paddingHorizontal: 14,
    borderRadius: 20,
    marginRight: 10,
  },
  filterText: {
    fontSize: 14,
  },
  results: {
    marginTop: 20,
  },
});