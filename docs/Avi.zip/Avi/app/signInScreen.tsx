import { StyleSheet } from 'react-native';

import SignInForm from "@/components/forms/SignInForm";
import { ThemedView } from '@/components/ThemedView';
import { useSingIn } from '@/hooks/forms/useSignIn';
import { useRouter } from 'expo-router';
import React from "react";

export default function SignInScreen() {

  const router = useRouter();

    const {
      form,
      submit,
      submitLabel,
      isLoading
    } = useSingIn({
      mode: "login",
      onSuccess: () =>
        router.push({
          pathname: "/tabs/searchHotelScreen"
        })
    })
    
  return (
    <ThemedView style={styles.container}>
      <SignInForm
        form={form}
        submitLabel={submitLabel}
        isLoading={isLoading}
        onSubmit={submit}
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 60,
  },
});
