declare namespace NodeJS {
  interface ProcessEnv {
    EXPO_PUBLIC_API_URL: string;
    EXPO_PUBLIC_APP_NAME: string;
    SEARCH_HISTORY_KEY: string;
  }
}

