import AsyncStorage from "@react-native-async-storage/async-storage";

export type SearchHistoryItem = {
    label: string;
    timestamp: number;
};

const SEARCH_HISTORY_KEY = process.env.EXPO_PUBLIC_SEARCH_HISTORY_KEY!; // le ! indique que ce n'est pas undefined

/**
 * Récupère l'historique de recherche
 * @returns 
 */
export async function getSearchHistory(): Promise<SearchHistoryItem[]> {

    const raw = await AsyncStorage.getItem(SEARCH_HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
}

/**
 * Sauvegarde la recherche de l'utilisateur
 * @param input la recherche de l'utilisateur
 */
export async function saveSearch(input: string) {
    const history = await getSearchHistory();

    // Supprime les doublons
    const filtered = history.filter(item => item.label !== input);

    const updated = [
        { label: input, timestamp: Date.now() },
        ...filtered,
    ].slice(0, 10); // max 10 recherches

    await AsyncStorage.setItem(
        SEARCH_HISTORY_KEY,
        JSON.stringify(updated)
    );
}
