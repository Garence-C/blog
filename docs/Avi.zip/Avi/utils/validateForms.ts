import { EstablishmentFormValue } from "@/components/forms/add-establishment-form";
import { OpinionFormValue } from "@/components/forms/OpinionForm";

export function validateOpinion(value: OpinionFormValue) {
  if (!value.price && Number(value.price) >= 0) return "Prix obligatoire et >= 0";
  if (!value.rating) return "Note obligatoire";

  console.log("validateOpinion(): OK");
}

// TODO : validateEstablishment
export function validateEstablishment(value: EstablishmentFormValue) {
  return null;
}


