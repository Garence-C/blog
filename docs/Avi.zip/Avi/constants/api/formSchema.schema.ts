import { z } from "zod";

export const OpinionCreateInputSchema = z.object({
  price: z
    .number({ message: "Le prix doit être positif." })
    .min(0, { message: "Le prix doit être supérieur ou égal à 0." }),

  rating: z
    .number({ message: "Vous devez noter votre expérience." })
    .min(1, { message: "La note doit être supérieure à 0." })
    .max(5, { message: "La note doit être inférieure à 5." }),

  commentary: z
    .string()
    .min(1, { message: "Décrivez votre expérience en quelques mots." })
    .max(2000),
});

export const OpinionUpdateSchema = OpinionCreateInputSchema.partial();

export type OpinionCreateInput = z.infer<typeof OpinionCreateInputSchema>;
export type OpinionUpdateInput = z.infer<typeof OpinionUpdateSchema>;
