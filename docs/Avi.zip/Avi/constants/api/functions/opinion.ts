import { apiFetch } from "../client";
import { OpinionUpdateInput } from "../schemas/opinion.schema";


/**
 * Récupère l'opinion de l'utilisateur
 * 
 * @param id identifiant de l'opinion
 * @returns 
 */
export async function getOpinion(
    id: number
) {
    const response = await apiFetch(`/opinions/${id}`, {
        method: "GET",

    })
    if (!response.ok) {
        throw new Error("Failed to fetch opinion n°" + id);
    }

    return response.json();

}


/**
 * Mise à jour de l'opinion d'un utilisateur
 * 
 * @param id identifiant de l'opinion
 * @param data Données qui sont modifiées (price, rating ou commentary)
 * @returns 
 */
export async function updateOpinion(
    id: number,
    data: OpinionUpdateInput
) {
    const response = await apiFetch(`/opinions/${id}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    })

    if (!response.ok) {
        throw new Error("Failed to fetch opinion n°" + id);
    }

    return response.json();
}


export async function deleteOpinion(opinionId: number): Promise<void> {
    const res = await apiFetch(`/opinions/${opinionId}`, {
        method: "DELETE",
        // SURTOUT PAS DE body
        // SURTOUT PAS DE headers
    });

    if (res.status === 204) return;

    const text = await res.text();
    throw new Error(
        `Failed to delete opinion ${opinionId} (status ${res.status}) : ${text}`
    );
}
