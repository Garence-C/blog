import { EstablishmentsResponse, EstablishmentsResponseSchema, FullEstablishmentCreateInput, FullEstablishmentCreateResponseSchema, FullEstablishmentUpdateInput, FullEstablishmentUpdateResponseSchema } from '@/constants/api/schemas/establishment.schema';
import { OpeningInfos } from '@/hooks/tanStack/useOpeningInfos';
import { apiFetch } from '../client';
import { OpinionCreateInput, OpinionListItemResponse, OpinionListResponse } from '../schemas/opinion.schema';

type CreateOpinionParams = {
  establishmentId: number;
  data: OpinionCreateInput;
};

export type EstablishmentByIdResponse = {
  establishment: EstablishmentsResponse["establishments"][number],
  infos?: OpeningInfos["infos"];
}

/**
 * Crée un établissement complet 
 * 
 * @param input données envoyées
 * @returns 
 */
export async function createEstablishment(
  input: FullEstablishmentCreateInput,
) {
  const res = await apiFetch('/establishments/full', {
    method: 'POST',
    body: JSON.stringify(input),
  });

  if (!res.ok) {
    if (res.status === 401) {
      throw new Error('UNAUTHORIZED');
    }
    const text = await res.text().catch(() => 'Erreur lors de la création');
    throw new Error(text || 'Erreur lors de la création');
  }

  const data = await res.json();
  return FullEstablishmentCreateResponseSchema.parse(data);
}


/**
 * Met à jour les données d'un établissement
 * 
 * @param input Données envoyées 
 */
export async function updateEstablishment(
  establishmentId: number,
  input: FullEstablishmentUpdateInput,
) {
  const res = await apiFetch(`/establishments/full/${establishmentId}`, {
    method: 'PATCH',
    body: JSON.stringify(input),
  });

  if (!res.ok) {
    if (res.status === 401) {
      throw new Error('UNAUTHORIZED');
    }
    const text = await res.text().catch(() => 'Erreur lors de la mise à jour');
    throw new Error(text || 'Erreur lors de la mise à jour');
  }

  const data = await res.json();
  return FullEstablishmentUpdateResponseSchema.parse(data);
}


/**
 * Récupère tous les établissements
 * 
 * @returns 
 */
export async function getEstablishments(): Promise<EstablishmentsResponse> {
  const response = await apiFetch(`/establishments`, {
    method: 'GET',
  });

  if (!response.ok) {
    throw new Error("Failed to fetch establishments");
  }

  const data = await response.json();

  try {
    return EstablishmentsResponseSchema.parse(data);
  } catch (error) {
    console.error("ZOD ERROR", error);
    throw error;
  }

}


/**
 * Récupère les opinions d'un établissement
 * 
 * @param establishmentId identifiant de l'établissement
 * @returns le nombre total d'opinions et un tablea ucontenant toutes les opinions de l'établissement
 */
export async function getOpinionsByEstablishmentId(establishmentId: number): Promise<OpinionListResponse> {

  const response = await apiFetch(`/establishments/${establishmentId}/opinions`, {
    method: 'GET',
  });

  if (!response.ok) {
    throw new Error("Failed to fetch opinions of establishment n°" + establishmentId);
  }

  const data = await response.json();

  try {
    return OpinionListItemResponse.parse(data);
  } catch (error) {
    console.error("ZOD ERROR", error);
    throw error;
  }

}

/**
 * Crée un établissmeent complet (données de base, son type et une opinion)
 * 
 * @param data Données concernant la création d'un établissement 
 * @returns Renvoie les données enregistrées
 */
export async function createOpinion({
  establishmentId,
  data,
}: CreateOpinionParams) {
  const res = await apiFetch(`/establishments/${establishmentId}/opinions`, {
    method: "POST",
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    const message = await res.text();
    throw new Error(message || "Erreur lors de l’ajout de l’avis");
  }


  return res.json();
}



/**
 * Récupère les données d'ouverture de l'établissement
 * 
 * @param establishmentId identifiant de l'établissement
 * @returns les informations de base d'un
 */
export async function getEstablishmentById(establishmentId: number): Promise<EstablishmentByIdResponse> {
  const res = await apiFetch(`/establishments/${establishmentId}`, { method: 'GET' });

  if (!res.ok) {
    throw new Error("Erreur réseau : " + res.statusText);
  }
  const data = await res.json();

  return data;
};
