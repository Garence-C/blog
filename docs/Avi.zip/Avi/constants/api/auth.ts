import { apiFetch, setToken } from './client';

export async function loginApi(email: string, password: string) {
  const res = await apiFetch('/users/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => 'error');
    throw new Error(text || 'Login failed');
  }

  const data = await res.json();
  const { accessToken } = data;
  if (!accessToken) throw new Error('No accessToken returned');

  await setToken(accessToken);
  return accessToken;
}
