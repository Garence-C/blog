import { z } from "zod";
import { HotelInfosCreateInputSchema, HotelInfosCreateResponseSchema, HotelInfosUpdateInputSchema } from "./hotelInfos.schema";
import { OpinionCreateInputSchema, OpinionResponseSchema } from "./opinion.schema";
import { RestaurantInfosCreateInputSchema, RestaurantInfosCreateResponseSchema, RestaurantInfosUpdateInputSchema } from "./restaurantInfos.schema";

const establishmentFields = {
    name: z.string()
        .max(100, { message: "Name must be at most 100 characters" })
        .meta({ description: "Nom de l'établissement" }),
    city: z.string()
        .max(100, { message: "City must be at most 100 characters" })
        .meta({ description: "La ville où l'établissement est situé" }),
    postCode: z.string()
        .length(5, { message: "PostCode must be equal to 5 characters" })
        .meta({ description: "Code postal de l'établissement" }),
    tel: z.string()
        .length(10, { message: "Tel must be equal to 10 characters" })
        .meta({ description: "Numéro de téléphone de l'établissement" }),
    address: z.string()
        .max(200, { message: "Address mut be at most 200 characters" })
        .meta({ description: "Adresse (rue) de l'établissmeent" }),
    longitude: z.string()
        .max(200, { message: "Longitude must be at most 200 characters" })
        .meta({ description: "Coordonnées GPS - Longitude" }),
    latitude: z.string()
        .max(200, { message: "Latitude must be at most 200 characters" })
        .meta({ description: "Coorodnnées GPS - Latitude" }),
    // TODO : rendre l'email optionnel et corriger l'erreur de type produite dans le contrôleur.
    email: z.email({ message: "Email must be a valid email address" })
        .meta({ description: "Adresse email de l'établissement" }),
    typeId: z.number()
        .meta({ description: "Type de l'établissement : Hotel = 1 ; Restaurant = 2" }),
}

const establishmentSystemFields = {
    id: z.number(),
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
}

export const EstablishmentCreateInputSchema = z.object({
    ...establishmentFields
});

export const EstablishmentResponseSchema = z.object({
    ...establishmentFields,
    ...establishmentSystemFields
});

export const FullEstablishmentCreateInputSchema = z.object({
    establishment: EstablishmentCreateInputSchema,
    restaurantInfos: RestaurantInfosCreateInputSchema.optional(),
    hotelInfos: HotelInfosCreateInputSchema.optional(),
    opinion: OpinionCreateInputSchema,
}).superRefine((data, ctx) => {
    if (data.establishment.typeId === 1) {
        // Si l'établissemnt est un hôtel
        if (!data.hotelInfos || data.restaurantInfos) {
            ctx.addIssue({
                path: ["hotelInfos"],
                message: "Hotel infos are required when typeId = 1",
                code: "custom"
            });
        }
    }

    if (data.establishment.typeId === 2) {
        // Si l'établissement est un restaurant
        if (!data.restaurantInfos || data.hotelInfos) {
            ctx.addIssue({
                path: ["restaurantInfos"],
                message: "Restaurant infos are required when typeId = 2",
                code: "custom"
            });
        }
    }
});

export const FullEstablishmentCreateResponseSchema = z.object({
    establishment: EstablishmentResponseSchema,
    hotelInfos: HotelInfosCreateResponseSchema.optional(),
    restaurantInfos: RestaurantInfosCreateResponseSchema.optional(),
    opinion: OpinionResponseSchema,
});


export const EstablishmentUpdateInputSchema = z.object({
    ...establishmentFields,
}).partial();


export const FullEstablishmentUpdateInputSchema = z.object({
    establishment: EstablishmentUpdateInputSchema.optional(),

    restaurantInfos: RestaurantInfosUpdateInputSchema
        .optional()
        .nullable(),

    hotelInfos: HotelInfosUpdateInputSchema
        .optional()
        .nullable(),
}).superRefine((data, ctx) => {
    const typeId = data.establishment?.typeId;

    // Pas de changement de type = OK
    if (typeId === undefined) return;

    // Devient un hotel
    if (typeId === 1) validateHotelRules(data, ctx);

    // Devient un restaurant
    if (typeId === 2) validateRestaurantRules(data, ctx);
});

// TODO : mettre les schémas de réponses
export const FullEstablishmentUpdateResponseSchema = z.object({
    establishment: EstablishmentResponseSchema,
    restaurantInfos: RestaurantInfosUpdateInputSchema.optional(),
    hotelInfos: HotelInfosUpdateInputSchema.optional(),
});




export type FullEstablishmentCreateInput = z.infer<typeof FullEstablishmentCreateInputSchema>
export type FullEstablishmentUpdateInput = z.infer<typeof FullEstablishmentUpdateInputSchema>

/**
 * Validation des données pour un établissement de type hôtel (typeId = 1)
 * 
 * @param data Données à valider pour un établissement de type hôtel (typeId = 1)
 * @param ctx Contexte de validation Zod
 */
function validateHotelRules(
    data: FullEstablishmentUpdateInput,
    ctx: z.RefinementCtx
) {
    if (!data.hotelInfos) {
        // Si hotelInfos n'est pas dans le body 
        ctx.addIssue({
            path: ["hotelInfos"],
            message: "hotelInfos is required when typeId = 1",
            code: "custom",
        });
    }

    if (data.restaurantInfos) {
        // Si restaurantInfos est dans le body, alors que ce n'est pas censé être le cas
        ctx.addIssue({
            path: ["restaurantInfos"],
            message: "restaurantInfos must not be provided when typeId = 1",
            code: "custom",
        });
    }

    // Vérification des champs obligatoires
    const requiredFields = ["breakfast", "stageEvening"];
    if (data.hotelInfos) {
        // Si hotelInfos est présent, on vérifie que tous les champs obligatoires le sont aussi
        for (const field of requiredFields) {
            if (data.hotelInfos[field as keyof typeof data.hotelInfos] === undefined) {
                ctx.addIssue({
                    path: ["hotelInfos", field],
                    message: `${field} is required when typeId = 1`,
                    code: "custom",
                });
            }
        }
    }
}

/**
 * Validation des données pour un établissement de type restaurant (typeId = 2)
 * 
 * @param data Données à valider pour un établissement de type restaurant (typeId = 2)
 * @param ctx Contexte de validation Zod
 */
function validateRestaurantRules(
    data: FullEstablishmentUpdateInput,
    ctx: z.RefinementCtx
) {
    if (!data.restaurantInfos) {
        // Si restaurantInfos n'est pas dans le body
        ctx.addIssue({
            path: ["restaurantInfos"],
            message: "restaurantInfos is required when typeId = 2",
            code: "custom",
        });
    }

    if (data.hotelInfos) {
        // Si hotelInfos est dans le body, alors que ce n'est pas censé être le cas
        ctx.addIssue({
            path: ["hotelInfos"],
            message: "hotelInfos must not be provided when typeId = 2",
            code: "custom",
        });
    }

    // Vérification des champs obligatoires
    const requiredFields = ["midday", "evening"];
    if (data.restaurantInfos) {
        // Si restaurantInfos est présent, on vérifie que tous les champs obligatoires le sont aussi
        for (const field of requiredFields) {
            if (data.restaurantInfos[field as keyof typeof data.restaurantInfos] === undefined) {
                ctx.addIssue({
                    path: ["restaurantInfos", field],
                    message: `${field} is required when typeId = 2`,
                    code: "custom",
                });
            }
        }
    }
}

// TYPES application
// POST /
export type FullEstablishmentCreateResponse = z.infer<typeof FullEstablishmentCreateResponseSchema>


// Réponse GET /establishments
export const EstablishmentListItemSchema =
    EstablishmentResponseSchema.extend({
        countOpinions: z.number(),
        averagePrice: z.number(),
        averageRating: z.number(),
    }); // .omit({ email: true })


// pour afficher les infos d'ouverture de l'hôtel
const HotelWithInfosSchema = z.object({
    establishment: EstablishmentResponseSchema.extend({
        typeId: z.literal(1),
    }),
    infos: HotelInfosCreateInputSchema,
});

// Pour afficher les informations d'ouverture du restaurant
const RestaurantWithInfosSchema = z.object({
    establishment: EstablishmentResponseSchema.extend({
        typeId: z.literal(2),
    }),
    infos: RestaurantInfosCreateInputSchema,
});

// export const EstablishmentWithRelativesInfosResponseSchema =
//   z.discriminatedUnion('establishment.typeId', [
//     HotelWithInfosSchema,
//     RestaurantWithInfosSchema,
//   ]);

export const EstablishmentWithStatsAndOpeningInfosSchema = z.discriminatedUnion(
  "typeId",
  [
    EstablishmentListItemSchema.extend({
      typeId: z.literal(2),
      ...RestaurantInfosCreateInputSchema.shape,
    }),

    EstablishmentListItemSchema.extend({
      typeId: z.literal(1),
      ...HotelInfosCreateInputSchema.shape,
    }),
  ]
);

export const EstablishmentsResponseSchema = z.object({
    countEstablishments: z.number(),
    establishments: z.array(EstablishmentWithStatsAndOpeningInfosSchema),
});

export const GetEstablishmentsResponseSchema = z.object({
  countEstablishments: z.number(),
  establishments: z.array(
    EstablishmentWithStatsAndOpeningInfosSchema
  ),
});

export type EstablishmentsResponse = z.infer<
    typeof GetEstablishmentsResponseSchema
>;


// export type EstablishmentsWithRelativesInfosResponse = z.infer<
//   typeof EstablishmentWithRelativesInfosResponseSchema
// >;