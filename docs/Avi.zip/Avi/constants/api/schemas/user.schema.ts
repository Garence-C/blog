import { z } from "zod";

const userFields = {
    email: z.email({ message: "Email must be a valid email address" }),
    pseudo: z.string()
        .min(2, { message: "Pseudo must be at least 2 characters" })
        .max(100, { message: "Pseudo must be at most 100 characters" }),
};

export const UserCreateInputSchema = z.object({
    ...userFields,
    password: z.string()
        .min(12, { message: "Password must be at least 12 characters" })
        .max(48, { message: "Password must be at most 48 characters" }),
});

export const UserResponseSchema = z.object({
    id: z.number(),
    ...userFields
});

export const UserLoginInputSchema = z.object({
    email: z.email({ message: "Email must be a valid email address" }),
    password: z.string()
        .min(12, { message: "Password must be at least 12 characters" })
        .max(48, { message: "Password must be at most 48 characters" }), // possibilité d'ajouter un REGEX pour avoir un mot de passe avec des chractères spéciaux.
    rememberMe: z.boolean().optional(),


})

export const UserLoginResponseSchema = z.object({
    accessToken: z.string()
})

export type UserCreateInput = z.infer<typeof UserCreateInputSchema>;
export type UserLoginInput = z.infer<typeof UserLoginInputSchema>
