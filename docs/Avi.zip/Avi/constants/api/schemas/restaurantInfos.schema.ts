import { z } from 'zod'

const restaurantInfosInput = {
    midday: z.boolean({ message: "Midday must be a boolean value" }),
    evening: z.boolean({ message: "Evening must be a boolean value" })
}

const restaurantInfosSystemFields = {
    id: z.number()
}

export const RestaurantInfosCreateInputSchema = z.object({
    ...restaurantInfosInput
});

export const RestaurantInfosCreateResponseSchema = z.object({
    ...restaurantInfosSystemFields,
    ...restaurantInfosInput,
    establishmentId: z.number()
})

export const RestaurantInfosUpdateInputSchema = z.object({
    ...restaurantInfosInput
}).partial();

