import { z } from "zod";

const opinionInput = {
    price: z.number({ message: "Price must be a number" }).min(0, {message: "Price must be equal or superior to 0"}),
    rating: z.number({ message: "Rating must be a number" })
        .min(1, { message: "Rating must be at least equal or superior to 1" })
        .max(5, { message: "Rating must be at most equal or inferior to 5" }),
    commentary: z.string()
        .min(1, { message: "Commentary cannot be empty" })
        .max(2000)
};

const opinionSystemFields = {
    id: z.number(),
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
};

export const OpinionCreateInputSchema = z.object({
    ...opinionInput
});

export const OpinionResponseSchema = z.object({
    ...opinionSystemFields,
    ...opinionInput,
    userId: z.number(),
    establishmentId: z.number()
});


export const OpinionUpdateSchema = z.object({
    ...opinionInput
}).partial();



export type OpinionCreateInput = z.infer<typeof OpinionCreateInputSchema>
export type OpinionUpdateInput = z.infer<typeof OpinionUpdateSchema>

// TYPES application

export const OpinionByEstablishmentSchema = z.object({
    id: z.number(),
    createdAt: z.string(), // ISO
    updatedAt: z.string(),
    price: z.number().min(0, {message: "Price must be equal or superior to 0"}),
    rating: z.number().min(1).max(5),
    commentary: z.string().min(1).max(2000),
    userId: z.number(),
});

export const OpinionListItemResponse = z.object({
    countOpinions: z.number(),
    opinions: z.array(OpinionByEstablishmentSchema),
});


export type OpinionResponse = z.infer<typeof OpinionResponseSchema>
export type OpinionListResponse = z.infer<typeof OpinionListItemResponse>
