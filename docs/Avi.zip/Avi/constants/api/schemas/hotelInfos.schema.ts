import { z } from 'zod'

const hotelInfosInput = {
    breakfast: z
        .boolean({ message: "Breakfast must be a boolean value" })
        .meta({ description: "je suis le champ breakfast" }),
    stageEvening: z
        .boolean({ message: "StageEvening must be a boolean value" })
        .meta({ description: "je suis le champ stageEvening" })
};

const hotelInfosSystemFields = {
    id: z.number()
};

export const HotelInfosCreateInputSchema = z.object({
    ...hotelInfosInput
});

export const HotelInfosCreateResponseSchema = z.object({
    ...hotelInfosInput,
    ...hotelInfosSystemFields,
    establishmentId: z.number()
});

export const HotelInfosUpdateInputSchema = z.object({
    ...hotelInfosInput
}).partial();

