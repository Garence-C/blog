import { z } from "zod";

const establishmentTypeInput = {
    description: z.string()
        .min(1, { message: "Description must be at least 1 character" })
        .max(30, { message: "Description must be at most 30 characters" })
}

const establishmentTypeGenerated = {
    id: z.number(),
}

export const EstablishmentTypeCreateInputSchema = z.object({
    ...establishmentTypeInput
})

export const EstablishmentTypeResponseSchema = z.object({
    ...establishmentTypeGenerated,
    ...establishmentTypeInput
})

export type EstablishmentTypeCreateInput = z.infer<typeof EstablishmentTypeCreateInputSchema>
