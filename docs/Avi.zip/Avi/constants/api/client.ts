import * as SecureStore from 'expo-secure-store';

const API_URL = process.env.EXPO_PUBLIC_API_URL;


let tokenCache: string | null = null;

async function getToken(): Promise<string | null> {
  if (tokenCache) return tokenCache;
  const accessToken = await SecureStore.getItemAsync('accessToken');
  tokenCache = accessToken;
  return accessToken;
}

export async function setToken(token: string) {
  tokenCache = token;
  await SecureStore.setItemAsync('accessToken', token);
}

export async function clearToken() {
  tokenCache = null;
  await SecureStore.deleteItemAsync('accessToken');
}

/**
 * Wrapper autour de fetch() qui prend en compte le token d'accès et qui préfixe la route APIa ve l'URL de l'API.
 * apiFetch: wrapper autour de fetch qui ajoute header Authorization si token présent,
 * et gère 401 en renvoyant une erreur spéciale.
 */
export async function apiFetch(path: string, opts: RequestInit = {}) {
  const token = await getToken();

  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string> || {}),
  };

  // DELETE sans body → on FORCE la suppression du Content-Type
  if (opts.method === "DELETE" && !opts.body) {
    delete headers["Content-Type"];
  }

  if (opts.body) {
    headers["Content-Type"] = "application/json";
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_URL}${path}`, {
    ...opts,
    headers,
  });

  if (res.status === 401) {
    throw new Error("UNAUTHORIZED");
  }

  return res;
}

