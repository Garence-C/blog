export const Colors = {
  light: {
    tint: '#FFFFFF',
    black: '#000000',
    grayLight: '#F6F6F6',
    grayDark: '#656565',
    grayMedium: '#E4E4E4',
    pinkDark: '#B9375E',
    pinkMediumDark: '#E05780',
    pinkLowDark: '#FF7AA2',
    pink: '#FF9EBB',
    pinkLowLight: '#FFC2D4',
    pinkMediumLight: '#FFE0E9',
  },
  // Même couleur que le thème light
  dark: {
    tint: '#FFFFFF',
    black: '#000000',
    grayLight: '#F6F6F6',
    grayDark: '#656565',
    grayMedium: '#E4E4E4',
    pinkDark: '#B9375E',
    pinkMediumDark: '#E05780',
    pinkLowDark: '#FF7AA2',
    pink: '#FF9EBB',
    pinkLowLight: '#FFC2D4',
    pinkMediumLight: '#FFE0E9',
  },
};
