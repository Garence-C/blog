import { jwtDecode } from 'jwt-decode';

export type JwtPayload = { id: number; email?: string; pseudo?: string; [k:string]: any };

export function decodeToken(token: string): JwtPayload | null {
  try {
    return jwtDecode<JwtPayload>(token);
  } catch {
    return null;
  }
}
