const radius = 20;

export const BorderRadius = {
  large: radius,
  medium: radius - 2,
  small: radius - 4,
};
