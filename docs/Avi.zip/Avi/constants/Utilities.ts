const API_URL = process.env.EXPO_PUBLIC_API_URL;

/**
 * Obtenir l'API_URL complète d'un fichier, principalement des images
 *
 * @param ref chemin d'accès récupérés via le fichier JSON
 * @returns
 */
export const getImageUrl = (ref: string) => `${API_URL}${ref}`; // Adapte à ton IP

/**
 * Calcule la moyenne arrondie à l'entier le plus proche des valeurs associées à une clé spécifique dans un tableau d'objets.
 *
 * @param tab - Tableau d'objets contenant les tab à traiter.
 * @param key - Clé dont les valeurs numériques seront utilisées pour le calcul de la moyenne.
 * @param decimals - Booléen qui affiche la valeur en décimal si vrai.
 * @returns La moyenne arrondie à l'entier le plus proche, ou 0 si le tableau est vide ou non défini.
 */
export const getAverageNumber = (
  tab: Record<string, any>[],
  key: string,
  decimals: boolean
) => {
  // Si le tableau est vide ou non défini, on retourne 0 directement
  if (!tab || tab.length === 0) return 0;

  // On additionne toutes les valeurs correspondant à la clé spécifiée dans chaque objet
  // Si la clé est absente dans un objet, on ajoute 0 par défaut
  const sum = tab.reduce((acc, curr) => acc + (curr[key] || 0), 0);

  // Affiche ou non les décimales
  const result = decimals
    ? Math.round(sum / tab.length).toFixed(2)
    : Math.round(sum / tab.length);

  // Retourne la moyenne arrondie à l'entier le plus proche
  return result;
};

// export const getCount = (
//   tab: Record<string, any>[]
// ) => {
//   // Si le tableau est vide ou non défini, on retourne 0 directement
//   if (!tab || tab.length === 0) return 0;

//   let sum = 0;
//   tab.forEach((item) => {
//     sum += 1;
//   });

//   // Retourne la somme
//   return sum;
// }


// Prend une date ISO et retourne le jour du mois (ex: 10 pour "2025-06-10T14:32:39.438Z")
export function getDayFromIsoDate(isoString: string): number {
  const date = new Date(isoString);
  return date.getDate(); // Retourne le jour du mois (1-31)
}

/**
 * Calcule la différence de temps en jours, heures et minutes entre aujourd'hui et une date ISO (ex: "2025-06-10T14:32:39.438Z")
 * @param isoString - La date au format ISO
 * @returns Le nombre de jours, heures et minutes de différence (peut être négatif si la date est dans le passé)
 */
export function getDiffTime(isoString: string): string {
  const today = new Date();
  const targetDate = new Date(isoString);
  const millisecondsInOneDay = 1000 * 3600 * 24;

  // Réinitialise l'heure pour ne comparer que les jours
  today.setHours(0, 0, 0, 0);
  targetDate.setHours(0, 0, 0, 0);

  const diffTimeMilli = today.getTime() - targetDate.getTime(); // le résultat est en millisecondes
  const diffDays = Math.round(diffTimeMilli / millisecondsInOneDay);
  console.log("Jours : ", diffDays);

  if (diffDays < 1) {
    return "Depuis aujourdhui";
  }

  return "Il y a " + diffDays.toString() + " jours";
}

export function getRatingStatus(rating: number, type: number) {
  if (type === 1) {
    if (rating >= 4.5) {
      return "Excellent";
    } else if (rating >= 3.5) {
      return "Très douillet";
    } else if (rating >= 2.5) {
      return "Moyennement confortable";
    } else if (rating >= 1.5) {
      return "Moyen";
    } else if (rating >= 0.5) {
      return "A même le sol";
    } else {
      return "Très médiocre";
    }
  } else if (type === 2) {
    if (rating >= 4.5) {
      return "Excellent";
    } else if (rating >= 3.5) {
      return "Très bon";
    } else if (rating >= 2.5) {
      return "Bon";
    } else if (rating >= 1.5) {
      return "Moyen";
    } else if (rating >= 0.5) {
      return "Médiocre";
    } else {
      return "Très médiocre";
    }
  }
}